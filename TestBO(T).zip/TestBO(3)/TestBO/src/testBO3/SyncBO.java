package testBO3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class SyncBO extends BaseSend implements Runnable {
	private InetSocketAddress serverAddr;
	private InetSocketAddress clientAddr;
	public PrintWriter client;
	public BufferedReader serverReader;
	public BaseSend control;
	public String prefix;
	public char buffer[];
	
	public SyncBO(InetSocketAddress serverAddr, InetSocketAddress clientAddr, BaseSend control) {
		this.name = "Boundary";
		this.serverAddr = serverAddr;
		this.clientAddr = clientAddr;
		this.control = control;
		this.prefix = "";
	}
	
	@Override
	public void run() {
		while(true) {
			String event = this.getEvent();
			if(event != null) {
				this.write(event);
			} 
			try {
				if(Config.sameThreadForRW && 
						(!Config.polling || 
								(Config.polling && this.serverReader.ready()))) {
					this.read();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void write(String event) {
		client.println(event);
		client.flush();
	}
	
	public void read() {
		try {
			String message = serverReader.readLine();
			if(message == null) return;
			int pos = message.lastIndexOf(',') + 1;
			String[] msgList = message.substring(0, pos).split(",");
//			System.out.println("Read:" + message);
			for(int i = 0; i < msgList.length; i++) {
				this.control.sendEvent(msgList[i]);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void initServer() {
		try {
			ServerSocket serverSocket = new ServerSocket(serverAddr.getPort());
			Socket socket = serverSocket.accept();
			InputStream is = socket.getInputStream();
			serverReader = new BufferedReader(new InputStreamReader(is));
			if(!Config.sameThreadForRW) {
				new Thread(new Runnable() {

					@Override
					public void run() {
						try {
							while(true) {
								if(!Config.polling || (Config.polling && serverReader.ready())) {
									read();
								}
							}
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					
				}).start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void initClient() {
		try {
			Socket socket = new Socket(clientAddr.getHostName(), clientAddr.getPort());
			OutputStream os = socket.getOutputStream();
			this.client = new PrintWriter(os);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void channelRead(PrintWriter client2, SyncBO boundary) {
		
	}
}
