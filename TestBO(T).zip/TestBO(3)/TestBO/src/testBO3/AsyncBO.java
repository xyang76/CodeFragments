package testBO3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousServerSocketChannel;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class AsyncBO extends BaseSend implements Runnable {
	private InetSocketAddress serverAddr;
	public AsynchronousServerSocketChannel server;
	private InetSocketAddress clientAddr;
	public AsynchronousSocketChannel client;
	public AsynchronousSocketChannel channel;
	public BaseSend control;
	
	public AsyncBO(InetSocketAddress serverAddr, InetSocketAddress clientAddr, BaseSend control) {
		this.name = "Boundary";
		this.serverAddr = serverAddr;
		this.clientAddr = clientAddr;
		this.control = control;
	}
	
	@Override
	public void run() {
		while(true) {
			String event = this.getEvent();
			if(event != null) {
				this.write(event);
			}
		}
	} 
	
	public void initServer() {
		try {
			server = AsynchronousServerSocketChannel.open();
			server.bind(serverAddr);
			server.accept(this, new CompletionHandler<AsynchronousSocketChannel, AsyncBO>() {
				@Override
				public void completed(AsynchronousSocketChannel channel, AsyncBO me) {
					//server.accept(null, this);
					if(!Config.diffPort) {
						me.client = channel;	
					}
					me.channelRead(channel, me);
					System.out.println("Connect Success" + channel);
				}

				@Override
				public void failed(Throwable arg0, AsyncBO arg1) {
					
				}
			});
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void channelRead(AsynchronousSocketChannel channel, AsyncBO me) {
//		System.out.println("Start Read" + channel);
		final ByteBuffer buffer = ByteBuffer.allocate(1024);
		channel.read(buffer, "", new CompletionHandler<Integer, String>() {
			@Override
			public void completed(Integer result, String prefix) {
				if (result > 0) {
					buffer.flip();
					byte[] bytes = new byte[buffer.remaining()];
					buffer.get(bytes);
					String message = prefix + new String(bytes).trim();
					buffer.clear();

					int pos = message.lastIndexOf(',') + 1;
					channel.read(buffer, message.substring(pos), this);

//					System.out.println("BO Read: " + message);
					
					String[] msgList = message.substring(0, pos).split(",");
					for(int i = 0; i < msgList.length; i++) {
						me.control.sendEvent(msgList[i]);
					}
				}
			}

			@Override
			public void failed(Throwable exc, String attachment) {
				
				
			}
		});
	}

	public void initClient() {
		try {
			this.client = AsynchronousSocketChannel.open();
			this.client.connect(clientAddr).get();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
	}
	
	public void write(String msg) {
		ByteBuffer buffer = ByteBuffer.wrap(msg.getBytes());
		Future<Integer> f = client.write(buffer);
//		System.out.println("Write: " + msg);
		try {
			f.get();
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
	}
}
