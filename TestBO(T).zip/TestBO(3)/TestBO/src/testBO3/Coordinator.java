package testBO3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Hashtable;

public class Coordinator extends BaseSend implements Runnable{
	public SyncBO cohort1;
	public SyncBO cohort2;
	public SyncBO cohort3;
	public Hashtable<Integer, Integer> map;
	
	public Coordinator() {
		this.name = "Coordinator";
		map = new Hashtable<>();
		
		InetSocketAddress CoordinatorToCohort1 = new InetSocketAddress("localhost", 3882);
		InetSocketAddress CoordinatorToCohort2 = new InetSocketAddress("localhost", 3883);
		InetSocketAddress CoordinatorToCohort3 = new InetSocketAddress("localhost", 3884);
		
		InetSocketAddress CohortToCoordinator1 = new InetSocketAddress("localhost", 3885);
		InetSocketAddress CohortToCoordinator2 = new InetSocketAddress("localhost", 3886);
		InetSocketAddress CohortToCoordinator3 = new InetSocketAddress("localhost", 3887);
		
		
		cohort1 = new SyncBO(CohortToCoordinator1, CoordinatorToCohort1, this);
		cohort2 = new SyncBO(CohortToCoordinator2, CoordinatorToCohort2, this);
		cohort3 = new SyncBO(CohortToCoordinator3, CoordinatorToCohort3, this);
		
		cohort1.initServer();
		cohort2.initServer();
		cohort3.initServer();
		
		try {
			char i = 'n';
			while (i!='y' && i != 'Y') {
				System.out.println("Are you ready? Y/N");
			     i = (char) System.in.read(); 
			     System.in.read(); 
			}
		} catch (IOException e) {
			e.printStackTrace();
		} 
		
		if(Config.diffPort) {
			cohort1.initClient();
			cohort2.initClient();
			cohort3.initClient();
		}
		new Thread(cohort1).start();
		new Thread(cohort2).start();
		new Thread(cohort3).start();
	}
	
	public static void main(String[] args) throws IOException {
		new Coordinator().start();
	}
	
	public void start() {
		while(true) {
			String event = this.getEvent();
			if(event != null) {
				this.handle(event);
			}
		}
	}

	public void handle(String event) {
		String[] msgs = event.split(":");
		switch (msgs[0]) {
			case "StartRequest":
				startRequest(Integer.parseInt(msgs[1]));
				break;
			case "VoteYes":
				voteYes(Integer.parseInt(msgs[1]));
				break;
			case "VoteNo":
				voteNo(Integer.parseInt(msgs[1]));
				break;
			default:
				break;
		}
	}
	
	public void startRequest(int id) {
		map.put(id, 0);
//		System.out.println("--> COORDINATOR:startRequest " + id);
		sendToCohorts("StartRequest2:" +  id +",");
	}

	public void voteYes(int id) {
//		System.out.println("--> COORDINATOR:voteYes " + id);
		int voteYesCount = map.get(id) + 1;
		if (voteYesCount == 3) {
//			System.out.println("--> COORDINATOR:CoordDecisionCommit " + id);
			sendToCohorts("CoordDecisionCommit:" + id +",");
		} else {
			map.put(id, voteYesCount);
		}
		commit(id);
	}

	public void voteNo(int id) {
		sendToCohorts("CoordDecisionAbort:" + id +",");
		abort(id);
	}

	public void commit(int id) {
		//System.out.println("COORDINATOR: COMMIT");
	}

	public void abort(int id) {
		//System.out.println("COORDINATOR: ABORT");
	}
	
	private void sendToCohorts(String msg) {
		if(Config.writeToNewThread) {
			this.cohort1.sendEvent(msg);
			this.cohort2.sendEvent(msg);
			this.cohort3.sendEvent(msg);
		} else {
			this.cohort1.write(msg);
			this.cohort2.write(msg);
			this.cohort3.write(msg);
		}
	}

	@Override
	public void run() {
		this.start();
	}
}
