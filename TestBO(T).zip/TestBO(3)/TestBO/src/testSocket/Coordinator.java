package testSocket;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Hashtable;

public class Coordinator extends ControlObject{
	public SyncSocket[] cohorts;
	public Hashtable<Integer, Integer> map;
	
	public Coordinator() {
		map = new Hashtable<>();
		cohorts = new SyncSocket[4];
		
		InetSocketAddress CoordinatorToCohort1 = new InetSocketAddress("localhost", 3882);
		InetSocketAddress CoordinatorToCohort2 = new InetSocketAddress("localhost", 3883);
		InetSocketAddress CoordinatorToCohort3 = new InetSocketAddress("localhost", 3884);
		
		InetSocketAddress CohortToCoordinator1 = new InetSocketAddress("localhost", 3885);
		InetSocketAddress CohortToCoordinator2 = new InetSocketAddress("localhost", 3886);
		InetSocketAddress CohortToCoordinator3 = new InetSocketAddress("localhost", 3887);
		
		
		cohorts[1] = new SyncSocket(CohortToCoordinator1, CoordinatorToCohort1, this);
		cohorts[2] = new SyncSocket(CohortToCoordinator2, CoordinatorToCohort2, this);
		cohorts[3] = new SyncSocket(CohortToCoordinator3, CoordinatorToCohort3, this);
		

		cohorts[1].initServer();
		cohorts[2].initServer();
		cohorts[3].initServer();
		
		try {
			char i = 'n';
			while (i!='y' && i != 'Y') {
				System.out.println("Are you ready? Y/N");
			     i = (char) System.in.read(); 
			     System.in.read(); 
			}
		} catch (IOException e) {
			e.printStackTrace();
		} 
		
		if(Config.diffPort) {
			cohorts[1].initClient();
			cohorts[2].initClient();
			cohorts[3].initClient();
		}
//		new Thread(cohort1).start();
//		new Thread(cohort2).start();
//		new Thread(cohort3).start();
	}
	
	public static void main(String[] args) throws IOException {
		new Coordinator().start();
	}
	
	public void start() {
		try {
			while(true) {
				if(Config.sameThreadForRW) {
					for(int i = 1; i < cohorts.length; i++) {
						if(cohorts[i].serverReader.ready()) {
							cohorts[i].read();
						}
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void handle(String event) {
		String[] msgs = event.split(":");
		switch (msgs[0]) {
			case "StartRequest":
				startRequest(Integer.parseInt(msgs[1]));
				break;
			case "VoteYes":
				voteYes(Integer.parseInt(msgs[1]));
				break;
			case "VoteNo":
				voteNo(Integer.parseInt(msgs[1]));
				break;
			default:
				break;
		}
	}
	
	public void startRequest(int id) {
		map.put(id, 0);
//		System.out.println("--> COORDINATOR:startRequest " + id);
		sendToCohorts("StartRequest2:" +  id +",");
	}

	public void voteYes(int id) {
		int voteYesCount = map.get(id) + 1;
//		System.out.println(voteYesCount + "--> COORDINATOR:voteYes " + id);
		if (voteYesCount == 3) {
//			System.out.println("--> COORDINATOR:CoordDecisionCommit " + id);
			sendToCohorts("CoordDecisionCommit:" + id +",");
		} else {
			map.put(id, voteYesCount);
		}
		commit(id);
	}

	public void voteNo(int id) {
		sendToCohorts("CoordDecisionAbort:" + id +",");
		abort(id);
	}

	public void commit(int id) {
		//System.out.println("COORDINATOR: COMMIT");
	}

	public void abort(int id) {
		//System.out.println("COORDINATOR: ABORT");
	}
	
	private void sendToCohorts(String msg) {
		this.cohorts[1].write(msg);
		this.cohorts[2].write(msg);
		this.cohorts[3].write(msg);
	}

}
