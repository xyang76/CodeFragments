package testSocket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class SyncSocket {
	private InetSocketAddress serverAddr;
	private InetSocketAddress clientAddr;
	public PrintWriter client;
	public BufferedReader serverReader;
	public ControlObject control;
	public String prefix;
	public char buffer[];
	
	public SyncSocket(InetSocketAddress serverAddr, InetSocketAddress clientAddr, ControlObject control) {
		this.serverAddr = serverAddr;
		this.clientAddr = clientAddr;
		this.control = control;
		this.prefix = "";
	}
	
	public void write(String event) {
		client.println(event);
		client.flush();
	}
	
	public void read() {
		try {
			String message = serverReader.readLine();
			int pos = message.lastIndexOf(',') + 1;
			String[] msgList = message.substring(0, pos).split(",");
//			System.out.println(this.clientAddr.getPort() + "Read:" + message);
			for(int i = 0; i < msgList.length; i++) {
				this.control.handle(msgList[i]);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void initServer() {
		try {
			ServerSocket serverSocket = new ServerSocket(serverAddr.getPort());
			Socket socket = serverSocket.accept();
			InputStream is = socket.getInputStream();
			serverReader = new BufferedReader(new InputStreamReader(is));
			SyncSocket me = this;
			if(!Config.sameThreadForRW) {
				new Thread(new Runnable() {

					@Override
					public void run() {
						while(true) {
							try {
								if(!Config.polling || (Config.polling && serverReader.ready())) {
									me.read();
								}
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
				}).start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void initClient() {
		try {
			Socket socket = new Socket(clientAddr.getHostName(), clientAddr.getPort());
			OutputStream os = socket.getOutputStream(); 
			this.client = new PrintWriter(os);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
