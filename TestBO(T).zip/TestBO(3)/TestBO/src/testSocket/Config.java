package testSocket;

public class Config {
	public static boolean diffPort = true;
	public static boolean writeToNewThread = true;

	public static boolean BIO = true;
	public static boolean polling = false;
	public static boolean sameThreadForRW = false;
}
