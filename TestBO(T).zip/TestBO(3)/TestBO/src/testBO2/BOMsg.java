package testBO2;

import java.io.Serializable;

public class BOMsg implements Serializable{
	private static final long serialVersionUID = -7541420683621538868L;
	public String msg;
	
	public BOMsg(String string) {
		this.msg = string;
	}

}
