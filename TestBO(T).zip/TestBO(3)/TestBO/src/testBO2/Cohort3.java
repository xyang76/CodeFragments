package testBO2;

import java.io.IOException;
import java.net.InetSocketAddress;

public class Cohort3 extends BaseSend {
	public NewBO boundary;
	public int counter;
	
	public Cohort3() {
		this.name = "Cohort3";
		counter = 0;
		InetSocketAddress CoordinatorToCohort = new InetSocketAddress("localhost", 3884);
		InetSocketAddress CohortToCoordinator = new InetSocketAddress("localhost", 3887);
		
		boundary = new NewBO(CoordinatorToCohort, CohortToCoordinator, this);
		
		boundary.initClient();
		if(Config.diffPort) {
			boundary.initServer();
		} else {
			boundary.channelRead(boundary.client, boundary);
		}
		new Thread(boundary).start();
	}
	
	public void start() {
		while(true) {
			BOMsg event = this.getEvent();
			if(event != null) {
				this.handle(event.msg);
			}
		}
	}
	
	public void updateStatus(int id) {
//		System.out.println("--> COHORT: updateStatus" + id);
		boundary.sendEvent(new BOMsg("StartRequest:" + id + ","));
	}

	public void startRequest2(int id) {
//		System.out.println("--> COHORT: startRequest2" + id);
		boolean vote = true;

		if (vote) {
			boundary.sendEvent(new BOMsg("VoteYes:" + id + ","));
			// System.out.println("COHORT: VOTE YES -> WAIT");
		} else {

			boundary.sendEvent(new BOMsg("VoteNo:" + id + ","));
			// System.out.println("COHORT: VOTE NO -> ABORT");
			abort(id);
		}
	}

	public void coordDecisionCommit(int id) {
		commit(id);
	}

	public void coordDecisionAbort(int id) {
		abort(id);
	}

	public void commit(int id) {
		System.out.println("Time : " + (System.currentTimeMillis()) + "ms" + counter);
		counter++;
	}

	public void abort(int id) {
		System.out.println("Time : " + (System.currentTimeMillis()) + "ms" + counter);
		counter++;
	}
	
	public void handle(String event) {
		String[] msgs = event.split(":");
		switch (msgs[0]) {
		case "StartRequest2":
			startRequest2(Integer.parseInt(msgs[1]));
			break;
		case "CoordDecisionCommit":
			coordDecisionCommit(Integer.parseInt(msgs[1]));
			break;
		case "CoordDecisionAbort":
			coordDecisionAbort(Integer.parseInt(msgs[1]));
			break;
		default:
			break;
		}
	}

	public static void main(String[] args) throws IOException {
		new Cohort3().start();
	}
	
}
