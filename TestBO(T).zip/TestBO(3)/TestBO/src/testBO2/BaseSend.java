package testBO2;

import java.util.LinkedList;

public class BaseSend {
	protected LinkedList<BOMsg> queue;
	public String name;
	
	public BaseSend() {
		this.queue = new LinkedList<>();
	}
	
	public BOMsg getEvent() {
		synchronized(this.queue) {
			return this.queue.poll();
		}
	}

	public void sendEvent(BOMsg msg) {
		synchronized(this.queue) {
			this.queue.push(msg);
		}
	}
}
