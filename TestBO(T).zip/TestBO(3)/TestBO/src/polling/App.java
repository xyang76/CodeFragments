package polling;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;

public class App {
    final static int numMessage = 100_000;
    final static boolean debug = false;

    final static int bufferSize = 1024;
    final static String splitter = ",";
    final static String delimiter = ";";
    final static String XactionStart = "XactionStart";

    public static void main(String[] args) throws Exception {
        AsynchronousSocketChannel coordChannel = AsynchronousSocketChannel.open();
        coordChannel.connect(new InetSocketAddress("localhost", 8080)).get();

        ByteBuffer byteBuffer = ByteBuffer.allocate(bufferSize);
        Future<Integer> future = CompletableFuture.completedFuture(-1);
        final long start = System.currentTimeMillis();
        for (int i = 1; i <= numMessage; i++) {
            final String msg = i + splitter + XactionStart + delimiter;
            System.out.println("Sending Messages to Cohort" + i);

            future.get();
            byteBuffer.clear();
            byteBuffer.put(msg.getBytes());
            byteBuffer.flip();
            future = coordChannel.write(byteBuffer);
        }

        future.get();
        coordChannel.shutdownInput();
        System.out.println("Starting Time : " + start);
    }
}
