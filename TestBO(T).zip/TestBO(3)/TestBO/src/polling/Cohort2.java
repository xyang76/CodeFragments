package polling;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class Cohort2 {

  final boolean debug = false;
  final int bufferSize = 1024;
  final int waitTime = 5;
  final String delimiter = ";";
  final String splitter = ",";

  final String XactionStart = "XactionStart";
  final String XactionRequest = "XactionRequest";
  final String Commit = "Commit";
  final String Abort = "Abort";
  final String Yes = "yes";

  private ByteBuffer coordWriteBuffer;
  private ByteBuffer coordReadBuffer;
  private Future<Integer> coordReadFuture;
  private Future<Integer> coordWriteFuture;
  private StringBuilder coordPrefix;
  private HashMap<String, State> states;
  private AsynchronousSocketChannel coordChannel;
  private Queue<String> pendingYes = new LinkedList<>();

  private int numCommit = 0;

  enum State {
    START, WAIT, COMMIT, ABORT
  }

  public static void main(String[] args) throws Exception {
    Cohort2 c = new Cohort2();
    c.doLoop();
  }

  void doLoop() throws IOException, InterruptedException, ExecutionException {
    // setting
    coordChannel = AsynchronousSocketChannel.open();
    coordChannel.connect(new InetSocketAddress("localhost", 3886)).get();
    coordWriteBuffer = ByteBuffer.allocate(bufferSize);
    coordReadBuffer = ByteBuffer.allocate(bufferSize);
    coordReadFuture = coordChannel.read(coordReadBuffer);
    coordWriteFuture = CompletableFuture.completedFuture(0);
    coordPrefix = new StringBuilder();
    states = new HashMap<>();
    System.out.println("Loop starts here");
    while (coordChannel.isOpen()) {
      Thread.sleep(0);
      readFromCoord();
      sendYes();
    }
  }

  private void readFromCoord() throws InterruptedException, ExecutionException, IOException {
    if (coordChannel.isOpen()) {
      if (!coordReadFuture.isDone())
        return;
      final int read = coordReadFuture.get();
      if (read == -1) {
        if (debug)
          System.out.println("coordinator is closed");
        coordChannel.close();
        return;
      }
      coordReadBuffer.flip();
      byte[] bytes = new byte[coordReadBuffer.remaining()];
      coordReadBuffer.get(bytes);
      coordReadBuffer.clear();
      coordReadFuture = coordChannel.read(coordReadBuffer);
      final String Message = new String(bytes);

      if (debug)
        System.out.println("received from app: " + Message);

      coordPrefix.append(Message);

      final int pos = coordPrefix.lastIndexOf(delimiter);
      if (pos >= 0) {
        final String prefix = coordPrefix.substring(0, pos + 1);
        coordPrefix.delete(0, pos + 1);
        for (final String str : prefix.split(delimiter)) {
          final String[] ss = str.split(splitter);

          State state = states.get(ss[0]);

          switch (ss[1]) {
          case XactionRequest:
            pendingYes.add(ss[0]);
            break;
          case Commit:
            if (state != State.WAIT)
              throw new RuntimeException("wrong state");
            numCommit++;
            System.out.println("Time : " + (System.currentTimeMillis()) + "ms" + numCommit);
            break;
          default:
            throw new RuntimeException("should not be here");
          }
        }
      }
    }
  }

  private void sendYes() throws InterruptedException, ExecutionException {
    if (coordChannel.isOpen()) {
      if (!pendingYes.isEmpty()) {
        if (!coordWriteFuture.isDone())
          return;
        coordWriteFuture.get();
        String id = pendingYes.poll();
        final String msg = id + splitter + Yes + delimiter;
        if (debug)
          System.out.println("sending: " + msg);
        byte[] msgB = msg.getBytes();
        coordWriteFuture.get();
        coordWriteBuffer.clear();
        coordWriteBuffer.put(msgB);
        coordWriteBuffer.flip();
        coordWriteFuture = coordChannel.write(coordWriteBuffer);
        states.put(id, State.WAIT);
      }
    }
  }

}