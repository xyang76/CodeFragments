package polling;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class Coordinator {

	final boolean debug = false;
	final int bufferSize = 1024;
	final int waitTime = 5;
	final String delimiter = ";";
	final String splitter = ",";
	final int numCohorts = 3;

	final String XactionStart = "XactionStart";
	final String XactionRequest = "XactionRequest";
	final String Commit = "Commit";
	final String Abort = "Abort";
	final String Yes = "yes";

	enum State {
		START, WAIT, COMMIT, ABORT
	}

	public static void main(String[] args) throws Exception {
		Coordinator c = new Coordinator();
		c.doLoop();
	}

	void doLoop() throws IOException, InterruptedException, ExecutionException {
		// setting
		HashMap<String, State> states = new HashMap<>();
		HashMap<String, Integer> yeses = new HashMap<>();
		// HashMap<String, Integer> reqs = new HashMap<>();

		AsynchronousSocketChannel[] cohorts = new AsynchronousSocketChannel[numCohorts];
		AsynchronousServerSocketChannel[] servers = new AsynchronousServerSocketChannel[numCohorts];
		Object[] acceptFutures = new Object[numCohorts];
		for (int i = 0; i < numCohorts; i++) {
			servers[i] = AsynchronousServerSocketChannel.open();
			servers[i].bind(new InetSocketAddress("localhost", 3885 + i));
			if (debug)
				System.out.println("listening port: " + (3885 + i));
			acceptFutures[i] = servers[i].accept();
		}
		for (int i = 0; i < numCohorts; i++) {
			cohorts[i] = ((Future<AsynchronousSocketChannel>) acceptFutures[i]).get();
			if (debug)
				System.out.println("Acceptted at port " + (11111 + i));
		}
		ByteBuffer[] writeBuffers = new ByteBuffer[numCohorts];
		ByteBuffer[] readBuffers = new ByteBuffer[numCohorts];
		Object[] readFutures = new Object[numCohorts];
		Object[] writeFutures = new Object[numCohorts];
		Object[] reqQueue = new Object[numCohorts];
		Object[] comQueue = new Object[numCohorts];
		for (int i = 0; i < numCohorts; i++) {
			writeBuffers[i] = ByteBuffer.allocate(bufferSize);
			readBuffers[i] = ByteBuffer.allocate(bufferSize);
			readFutures[i] = cohorts[i].read(readBuffers[i]);
			writeFutures[i] = CompletableFuture.completedFuture(-1);
			reqQueue[i] = new LinkedList<String>();
			comQueue[i] = new LinkedList<String>();
		}
		StringBuilder[] prefixes = new StringBuilder[numCohorts];
		for (int i = 0; i < numCohorts; i++) {
			prefixes[i] = new StringBuilder();
		}
		if (debug)
			System.out.println("Loop starts here");

		while (true) {
			Thread.sleep(0);
			for (int j = 0; j < numCohorts; j++) {
				if (cohorts[j].isOpen()) {
					if (((Future<Integer>) readFutures[j]).isDone()) {
						final int read = ((Future<Integer>) readFutures[j]).get();
						if (read == -1) {
							System.out.println("cohort" + j + " is closed");
							cohorts[j].close();
							continue;
						}
						readBuffers[j].flip();
						byte[] bytes = new byte[readBuffers[j].remaining()];
						readBuffers[j].get(bytes);
						readBuffers[j].clear();
						readFutures[j] = cohorts[j].read(readBuffers[j]);

						final String Message = new String(bytes);

						if (debug)
							System.out.println("received from cohort" + j + ": " + Message);

						prefixes[j].append(Message);

						final int pos = prefixes[j].lastIndexOf(delimiter);
						if (pos > 0) {
							final String prefix = prefixes[j].substring(0, pos + 1);
							prefixes[j].delete(0, pos + 1);

							for (final String str : prefix.split(delimiter)) {
								final String[] ss = str.split(splitter);

								String msg;
								byte[] msgB;
								switch (ss[1]) {
								case XactionStart:
									if (!states.containsKey(ss[0])) {
										states.put(ss[0], State.START);
										yeses.put(ss[0], 0);
										// reqs.put(ss[0], 0);
									}
									State state = states.get(ss[0]);
									if (state != State.START) {
										throw new RuntimeException("wrong state");
									}
									for (int i = 0; i < numCohorts; i++) {
										((Queue<String>) reqQueue[i]).add(ss[0]);
									}
									states.put(ss[0], State.WAIT);
									break;
								case Yes:
									state = states.get(ss[0]);
									if (state != State.WAIT) {
										throw new RuntimeException("wrong state");
									}

									int numYes = yeses.get(ss[0]);
									numYes++;
									yeses.put(ss[0], numYes);
									if (numYes != numCohorts)
										continue;

									for (int i = 0; i < numCohorts; i++) {
										((Queue<String>) comQueue[i]).add(ss[0]);
									}
									states.put(ss[0], State.COMMIT);
									break;
								default:
									throw new RuntimeException("should not be here");
								}
							}
						}
					}
				}
			}

			//////////////////////
			for (int j = 0; j < numCohorts; j++) {
				if (cohorts[j].isOpen()) {
					Queue<String> q = (Queue<String>) reqQueue[j];
					if (q.isEmpty())
						continue;

					if (!((Future<Integer>) writeFutures[j]).isDone())
						continue;
					String ss = q.poll();
					String msg = ss + splitter + XactionRequest + delimiter;

					if (debug)
						System.out.println("sending: " + msg);

					byte[] msgB = msg.getBytes();

					((Future<Integer>) writeFutures[j]).get();
					writeBuffers[j].clear();
					writeBuffers[j].put(msgB);
					writeBuffers[j].flip();
					writeFutures[j] = cohorts[j].write(writeBuffers[j]);

					// int req = reqs.get(ss);

				}
			}
			////////////////

			//////////////////////
			for (int j = 0; j < numCohorts; j++) {
				if (cohorts[j].isOpen()) {
					Queue<String> q = (Queue<String>) comQueue[j];
					if (q.isEmpty())
						continue;

					if (!((Future<Integer>) writeFutures[j]).isDone())
						continue;
					String ss = q.poll();
					String msg = ss + splitter + Commit + delimiter;

					if (debug)
						System.out.println("sending: " + msg);

					byte[] msgB = msg.getBytes();

					((Future<Integer>) writeFutures[j]).get();
					writeBuffers[j].clear();
					writeBuffers[j].put(msgB);
					writeBuffers[j].flip();
					writeFutures[j] = cohorts[j].write(writeBuffers[j]);

					// int req = reqs.get(ss);

				}
			}
			////////////////

		}
	}
}