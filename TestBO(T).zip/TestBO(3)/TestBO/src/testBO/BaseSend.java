package testBO;

import java.util.LinkedList;

public class BaseSend {
	protected LinkedList<String> queue;
	public String name;
	
	public BaseSend() {
		this.queue = new LinkedList<>();
	}
	
	public String getEvent() {
		synchronized(this.queue) {
			return this.queue.poll();
		}
	}

	public void sendEvent(String msg) {
		synchronized(this.queue) {
			this.queue.push(msg);
		}
	}
}
