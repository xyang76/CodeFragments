package testBO;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousChannelGroup;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class AppMultipleConnections {

	public static void main(String[] args) {

		final int connections;
		final int messageSize;
		connections = Integer.parseInt(args[0]);
		messageSize = Integer.parseInt(args[1]);

		System.out.println("You will start " + messageSize + " requests");
		System.out.println("You will start " + connections + " connections");

		final AtomicInteger counter = new AtomicInteger(0);

		try {
			System.out.println("Starting Time : " + System.currentTimeMillis());
			System.out.println("Sending Messages to Cohort");
			InetSocketAddress clienthostAddress = new InetSocketAddress("localhost", 3881);
			final AsynchronousChannelGroup group = AsynchronousChannelGroup.withFixedThreadPool(5, Executors.defaultThreadFactory());

			for (int i = 1; i <= connections; i++) {
				System.out.println("Sending Messages to Cohort" + i);

				AsynchronousSocketChannel client = AsynchronousSocketChannel.open();
				client.connect(clienthostAddress, null, new CompletionHandler<Void, Void>() {

					@Override
					public void completed(Void result, Void attachment) {
						int id = counter.incrementAndGet();
						if (id <= messageSize) {
							byte[] message = new String("UpdateStatus:" + id + ",").getBytes();
							ByteBuffer buffer = ByteBuffer.wrap(message);
//							System.out.println("Sending: " + message);
							client.write(buffer, null, new CompletionHandler<Integer, Void>() {

								@Override
								public void completed(Integer result, Void attachment) {
									int id = counter.incrementAndGet();
									if (id <= messageSize) {
										byte[] message = new String("UpdateStatus:" + id + ",").getBytes();
//										System.out.println("Sending: " + message);
										ByteBuffer buffer = ByteBuffer.wrap(message);
										client.write(buffer, null, this);
									} else {
										try {
											client.close();
										} catch (IOException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
									}
								}

								@Override
								public void failed(Throwable exc, Void attachment) {
									// TODO Auto-generated method stub

								}
							});
						}
					}

					@Override
					public void failed(Throwable exc, Void attachment) {
						// TODO Auto-generated method stub

					}
				});
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Thread.sleep(1000000000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
