package testSocket2;

import java.util.LinkedList;

public abstract class ControlObject {
	public String name;
	
	public ControlObject() {
	}
	
	public abstract void handle(String event);
}
