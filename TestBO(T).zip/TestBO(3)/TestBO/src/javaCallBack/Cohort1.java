package javaCallBack;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousChannelGroup;
import java.nio.channels.AsynchronousServerSocketChannel;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

public class Cohort1 {
	public AtomicInteger i = new AtomicInteger(0);
	public AsynchronousSocketChannel coordinator;
	public final MyLock lock = new MyLock();
	public final AsynchronousChannelGroup group;
	public Cohort1() throws IOException {
		group = AsynchronousChannelGroup.withFixedThreadPool(5, Executors.defaultThreadFactory());

	}
	public static void main(String[] args) throws IOException {
		Cohort1 cohort1 = new Cohort1();
		cohort1.start();

		try {
			Thread.sleep(1000000000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void start() {
		try {
			InetSocketAddress cohortToCoordinator = new InetSocketAddress("localhost", 3885);// Cohort to Coordinator
			coordinator = AsynchronousSocketChannel.open();
			coordinator.connect(cohortToCoordinator, null, new CompletionHandler<Void, Void>() {

				@Override
				public void completed(Void result, Void attachment) {
					initServer(new InetSocketAddress("localhost", 3881));// APP
					initServer(new InetSocketAddress("localhost", 3882));// Coordinator to Cohort
				}

				@Override
				public void failed(Throwable exc, Void attachment) {
					// TODO Auto-generated method stub
					
				}
			});			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void initServer(InetSocketAddress serverhostAddress) {
		try {

			try {
				AsynchronousServerSocketChannel serverChannel = AsynchronousServerSocketChannel.open();
				serverChannel.bind(serverhostAddress);
				System.out.println("Server channel bound to port : " + serverhostAddress.getPort());
				System.out.println("Waiting for client to connect... ");
				// async call
				serverChannel.accept(null, new CompletionHandler<AsynchronousSocketChannel, Void>() {
					@Override
					public void completed(AsynchronousSocketChannel result, Void attachment) {
						serverChannel.accept(null, this);
						final AsynchronousSocketChannel clientChannel = result;

						//System.out.println("Messages from client: ");

						if ((clientChannel != null) && (clientChannel.isOpen())) {
							final ByteBuffer buffer = ByteBuffer.allocate(1024);

							// aync call2
							clientChannel.read(buffer, "", new CompletionHandler<Integer, String>() {
								@Override
								public void completed(Integer result, String prefix) {
									if (result > 0) {
										buffer.flip();
										byte[] bytes = new byte[buffer.remaining()];
										buffer.get(bytes);
										String message = prefix + new String(bytes).trim();		
										buffer.clear();

										int pos = message.lastIndexOf(',') + 1;
										clientChannel.read(buffer, message.substring(pos), this);

//										System.out.println("COHORT Read: " + message);
										
										String[] msgList = message.substring(0, pos).split(",");
										for (String msg : msgList) {
											String[] msgs = msg.split(":");
											switch (msgs[0]) {
											case "UpdateStatus":
												updateStatus(Integer.parseInt(msgs[1]));
												break;
											case "StartRequest2":
												startRequest2(Integer.parseInt(msgs[1]));
												break;
											case "CoordDecisionCommit":
												coordDecisionCommit(Integer.parseInt(msgs[1]));
												break;
											case "CoordDecisionAbort":
												coordDecisionAbort(Integer.parseInt(msgs[1]));
												break;
											default:
												break;
											}
										}

									} else if (result == -1) {
										System.out.println("client disconnected!!!");
									}
								}

								@Override
								public void failed(Throwable exc, String arg2) {
									// TODO Auto-generated method stub

								}

								public void updateStatus(int id) {
//									System.out.println("--> COHORT: updateStatus" + id);
									sendToCoordinator("StartRequest:" + id + ",");
								}

								public void startRequest2(int id) {
//									System.out.println("--> COHORT: startRequest2" + id);
									boolean vote = true;

									if (vote) {
										sendToCoordinator("VoteYes:" + id + ",");
										// System.out.println("COHORT: VOTE YES -> WAIT");
									} else {

										sendToCoordinator("VoteNo:" + id + ",");
										// System.out.println("COHORT: VOTE NO -> ABORT");
										abort(id);
									}
								}

								public void coordDecisionCommit(int id) {
									commit(id);
								}

								public void coordDecisionAbort(int id) {
									abort(id);
								}

								public void commit(int id) {
									System.out.println("Time : " + (System.currentTimeMillis()) + "ms" + (i.incrementAndGet()));
								}

								public void abort(int id) {
									System.out.println("Time : " + (System.currentTimeMillis()) + "ms" + (i.incrementAndGet()));
								}
								
								private void sendToCoordinator(String msg) {
									byte[] message = msg.getBytes();
									ByteBuffer buffer = ByteBuffer.wrap(message);
//									lock.lock();
//									coordinator.write(buffer, null, new CompletionHandler<Integer, Void>() {
//
//										@Override
//										public void completed(Integer result, Void attachment) {
//											lock.unlock();
//										}
//
//										@Override
//										public void failed(Throwable exc, Void attachment) {
//											// TODO Auto-generated method stub
//											
//										}
//									});
									synchronized (coordinator) {
										Future<Integer> future = coordinator.write(buffer);
										try {
											future.get();
										} catch (InterruptedException | ExecutionException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
									}
								}
							});
						} // end-if
					}

					@Override
					public void failed(Throwable exc, Void attachment) {
						// TODO Auto-generated method stub

					}
				});

			} catch (Exception e2) {
				e2.printStackTrace();
			}

		} finally {
		}
	}
}
