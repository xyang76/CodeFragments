package javaCallBack;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousChannelGroup;
import java.nio.channels.AsynchronousServerSocketChannel;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

public class Coordinator {
	public AsynchronousSocketChannel cohort1;
	public AsynchronousSocketChannel cohort2;
	public AsynchronousSocketChannel cohort3;
	public final MyLock lock1 = new MyLock();
	public final MyLock lock2 = new MyLock();
	public final MyLock lock3 = new MyLock();
	public ConcurrentHashMap<Integer, AtomicInteger> hashMap = new ConcurrentHashMap<>();
	public final AsynchronousChannelGroup group;
	public Coordinator() throws IOException {
		group = AsynchronousChannelGroup.withFixedThreadPool(5, Executors.defaultThreadFactory());

	}
	public static void main(String[] args) throws IOException {
		Coordinator coordinator = new Coordinator();
		coordinator.start();

		try {
			Thread.sleep(1000000000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void start() {
		try {
			InetSocketAddress CoordinatorToCohort1 = new InetSocketAddress("localhost", 3882);
			InetSocketAddress CoordinatorToCohort2 = new InetSocketAddress("localhost", 3883);
			InetSocketAddress CoordinatorToCohort3 = new InetSocketAddress("localhost", 3884);

			cohort1 = AsynchronousSocketChannel.open();
			cohort2 = AsynchronousSocketChannel.open();
			cohort3 = AsynchronousSocketChannel.open();

//			cohort1.connect(CoordinatorToCohort1, null, new CompletionHandler<Void, Void>() {
//
//				@Override
//				public void completed(Void result, Void attachment) {
//					cohort2.connect(CoordinatorToCohort2, null, new CompletionHandler<Void, Void>() {
//
//						@Override
//						public void completed(Void result, Void attachment) {
//							cohort3.connect(CoordinatorToCohort3, null, new CompletionHandler<Void, Void>() {
//
//								@Override
//								public void completed(Void result, Void attachment) {
//									initServer(new InetSocketAddress("localhost", 8082));//Cohort1 to Coordinator
//									initServer(new InetSocketAddress("localhost", 8084));//Cohort2 to Coordinator
//									initServer(new InetSocketAddress("localhost", 8086));//Cohort3 to Coordinator
//								}
//
//								@Override
//								public void failed(Throwable exc, Void attachment) {
//									// TODO Auto-generated method stub
//									
//								}
//							});
//							
//						}
//
//						@Override
//						public void failed(Throwable exc, Void attachment) {
//							// TODO Auto-generated method stub
//							
//						}
//					});
//				}
//
//				@Override
//				public void failed(Throwable exc, Void attachment) {
//					// TODO Auto-generated method stub
//					
//				}
//			});

			initServer(new InetSocketAddress("localhost", 3885));// Cohort1 to Coordinator
			initServer(new InetSocketAddress("localhost", 3886));// Cohort2 to Coordinator
			initServer(new InetSocketAddress("localhost", 3887));// Cohort3 to Coordinator
			
			char i = 'n';
			while (i!='y' && i != 'Y') {
				System.out.println("Are you ready? Y/N");
		         i = (char) System.in.read(); 
		         System.in.read(); 
			} 
			
			Future<Void> future1 = cohort1.connect(CoordinatorToCohort1);
			Future<Void> future2 = cohort2.connect(CoordinatorToCohort2);
			Future<Void> future3 = cohort3.connect(CoordinatorToCohort3);

			try {
				future3.get();
				future1.get();
				future2.get();
			} catch (InterruptedException | ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void initServer(InetSocketAddress serverhostAddress) {
		try {

			try {
				AsynchronousServerSocketChannel serverChannel = AsynchronousServerSocketChannel.open(
						);
				serverChannel.bind(serverhostAddress);
				System.out.println("Server channel bound to port : " + serverhostAddress.getPort());
				System.out.println("Waiting for client to connect... ");
				// async call
				serverChannel.accept(null, new CompletionHandler<AsynchronousSocketChannel, Void>() {

					@Override
					public void completed(AsynchronousSocketChannel result, Void attachment) {
						serverChannel.accept(null, this);
						final AsynchronousSocketChannel clientChannel = result;

						System.out.println("Messages from client: ");

						if ((clientChannel != null) && (clientChannel.isOpen())) {
							final ByteBuffer buffer = ByteBuffer.allocate(1024);

							// aync call2
							clientChannel.read(buffer, "", new CompletionHandler<Integer, String>() {
								@Override
								public void completed(Integer result, String prefix) {
									if (result > 0) {
										buffer.flip();
										byte[] bytes = new byte[buffer.remaining()];
										buffer.get(bytes);
										String message = prefix + new String(bytes).trim();
										buffer.clear();

										int pos = message.lastIndexOf(',') + 1;
										clientChannel.read(buffer, message.substring(pos), this);

//										System.out.println("COORDINATOR Read: " + message);
										
										String[] msgList = message.substring(0, pos).split(",");
										for (String msg : msgList) {
											String[] msgs = msg.split(":");
											switch (msgs[0]) {
											case "StartRequest":
												startRequest(Integer.parseInt(msgs[1]));
												break;
											case "VoteYes":
												voteYes(Integer.parseInt(msgs[1]));
												break;
											case "VoteNo":
												voteNo(Integer.parseInt(msgs[1]));
												break;
											default:
												break;
											}
										}

									} else if (result == -1) {
										System.out.println("client disconnected!!!");
									}
								}

								@Override
								public void failed(Throwable exc, String arg2) {
									// TODO Auto-generated method stub

								}

								public void startRequest(int id) {
//									System.out.println("--> COORDINATOR: startRequest" + id);
									hashMap.put(id, new AtomicInteger(0));
									sendToCohorts("StartRequest2:" +  id +",");
								}

								public void voteYes(int id) {
//									System.out.println("--> COORDINATOR:voteYes " + id);
									int voteYesCount = hashMap.get(id).incrementAndGet();
									if (voteYesCount == 3) {
										sendToCohorts("CoordDecisionCommit:" + id +",");
									}
									commit(id);
								}

								public void voteNo(int id) {
									sendToCohorts("CoordDecisionAbort:" + id +",");
									abort(id);
								}

								public void commit(int id) {
									//System.out.println("COORDINATOR: COMMIT");
								}

								public void abort(int id) {
									//System.out.println("COORDINATOR: ABORT");
								}
								
								private void sendToCohorts(String msg) {
									sendToCohort(msg, cohort1, lock1);
									sendToCohort(msg, cohort2, lock2);
									sendToCohort(msg, cohort3, lock3);
								}
								private void sendToCohort(String msg,AsynchronousSocketChannel cohort, MyLock lock) {
									byte[] message = msg.getBytes();
									ByteBuffer buffer = ByteBuffer.wrap(message);
//									lock.lock();
//									cohort.write(buffer, null, new CompletionHandler<Integer, Void>() {
//
//										@Override
//										public void completed(Integer result, Void attachment) {
//											lock.unlock();
//										}
//
//										@Override
//										public void failed(Throwable exc, Void attachment) {
//											// TODO Auto-generated method stub
//											
//										}
//									});
									synchronized (cohort) {
										Future<Integer> future = cohort.write(buffer);
										try {
											future.get();
										} catch (InterruptedException | ExecutionException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
									}
								}
							});
						} // end-if
					}

					@Override
					public void failed(Throwable exc, Void attachment) {
						// TODO Auto-generated method stub

					}
				});

			} catch (Exception e2) {
				e2.printStackTrace();
			}

		} finally {
		}
	}
}
