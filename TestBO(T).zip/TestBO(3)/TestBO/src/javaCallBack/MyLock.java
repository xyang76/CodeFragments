package javaCallBack;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class MyLock {
	private final AtomicBoolean mylock;
	
	public MyLock() {
		mylock = new AtomicBoolean(false);
	}
	
	public synchronized void lock(){
		while (mylock.get()) {
			
		}
		mylock.getAndSet(true);
	}
	public void unlock() {
		mylock.getAndSet(false);
	}
	
	public static void main(String[] args) {
		Executor executor = Executors.newCachedThreadPool();
		MyLock myLock = new MyLock();
		for(int i = 0; i < 2000; i++)
			executor.execute(new Test1(myLock));
		
		
	}
}

class Test1 implements Runnable{
	private final MyLock myLock;
	private static final AtomicInteger counter = new AtomicInteger(0);
	
	public Test1(MyLock myLock) {
		 this.myLock = myLock;
	}
	
	@Override
	public void run() {
		System.out.println("locking");
		myLock.lock();
		System.out.println("Afterlocking" + counter.incrementAndGet());
		Executor executor = Executors.newCachedThreadPool();
		executor.execute(new Test2(myLock));
	}
	
}

class Test2 implements Runnable{
	private final MyLock myLock;
	
	public Test2(MyLock myLock) {
		 this.myLock = myLock;
	}

	@Override
	public void run() {
		System.out.println("unlocking");
		myLock.unlock();
		System.out.println("unlocked");
	}
	
}