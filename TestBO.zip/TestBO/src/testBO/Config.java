package testBO;

public class Config {
	public static boolean diffPort = false;
	public static boolean writeToNewThread = true;
}
