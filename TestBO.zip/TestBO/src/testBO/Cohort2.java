package testBO;

import java.io.IOException;
import java.net.InetSocketAddress;

public class Cohort2 extends BaseSend {
	public BOChannel boundary;
	public int counter;
	
	public Cohort2() {
		this.name = "Cohort2";
		counter = 0;
		InetSocketAddress CoordinatorToCohort = new InetSocketAddress("localhost", 3883);
		InetSocketAddress CohortToCoordinator = new InetSocketAddress("localhost", 3886);
		
		boundary = new BOChannel(CoordinatorToCohort, CohortToCoordinator, this);
		
		boundary.initClient();
		if(Config.diffPort) {
			boundary.initServer();
		} else {
			boundary.channelRead(boundary.client, boundary);
		}
		new Thread(boundary).start();
	}
	
	public void start() {
		while(true) {
			String event = this.getEvent();
			if(event != null) {
				this.handle(event);
			}
		}
	}

	public void startRequest2(int id) {
//		System.out.println("--> COHORT: startRequest2" + id);
		boolean vote = true;

		if (vote) {
			boundary.sendEvent("VoteYes:" + id + ",");
			// System.out.println("COHORT: VOTE YES -> WAIT");
		} else {

			boundary.sendEvent("VoteNo:" + id + ",");
			// System.out.println("COHORT: VOTE NO -> ABORT");
			abort(id);
		}
	}

	public void coordDecisionCommit(int id) {
		commit(id);
	}

	public void coordDecisionAbort(int id) {
		abort(id);
	}

	public void commit(int id) {
		System.out.println("Time : " + (System.currentTimeMillis()) + "ms" + counter);
		counter++;
	}

	public void abort(int id) {
		System.out.println("Time : " + (System.currentTimeMillis()) + "ms" + counter);
		counter++;
	}
	
	public void handle(String event) {
		String[] msgs = event.split(":");
		switch (msgs[0]) {
		case "StartRequest2":
			startRequest2(Integer.parseInt(msgs[1]));
			break;
		case "CoordDecisionCommit":
			coordDecisionCommit(Integer.parseInt(msgs[1]));
			break;
		case "CoordDecisionAbort":
			coordDecisionAbort(Integer.parseInt(msgs[1]));
			break;
		default:
			break;
		}
	}

	public static void main(String[] args) throws IOException {
		new Cohort2().start();
	}
	
}
