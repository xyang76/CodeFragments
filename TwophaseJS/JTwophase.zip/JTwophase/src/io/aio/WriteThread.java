package io.aio;

public class WriteThread extends Thread {
	
	
	@Override
	public void run() {
		
	}
}
