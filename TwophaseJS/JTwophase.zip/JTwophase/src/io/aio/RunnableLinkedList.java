package io.aio;

import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.LinkedList;

public class RunnableLinkedList<E> extends LinkedList<E> implements Runnable {
	private static final long serialVersionUID = 1L;
	private String name;
	private RunnableLinkedList<E> me;
	private AsynchronousSocketChannel channel;
	
	public RunnableLinkedList() {
		super();
		this.name = "";
		me = this;
	}
	
	public void setChannel(AsynchronousSocketChannel channel) {
		this.channel = channel;
		Thread t = new Thread(this);
		t.start();
	}
	
	@Override
	public void run() {
		while(true) {
			if(!this.isEmpty()) {
				String msg = this.pollFirst().toString();
				ByteBuffer writeBuffer =  ByteBuffer.wrap(msg.getBytes());
				channel.write(writeBuffer, null, new CompletionHandler<Integer, Void>() {
					@Override
					public void completed(Integer result, Void attachment) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void failed(Throwable exc, Void attachment) {
						// TODO Auto-generated method stub
						
					}
					
				});
			} else {
				
			}
		}
		
	}

}
