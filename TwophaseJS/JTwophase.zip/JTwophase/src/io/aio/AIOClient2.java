package io.aio;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousChannelGroup;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.LinkedList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import base.MessageEvent;
import base.States;
import io.Message;

public class AIOClient2 {
	private String host;
	private int port;
	private AsynchronousSocketChannel socketChannel;
	private MessageEvent event;
	private AsynBufferedMessage bm;
	private ChannelLinkedList<String> queue;
	private boolean writing;
	private int size;

	public AIOClient2(String ip, int port) {
		this.host = ip;
		this.port = port;
		this.size = 1024;
		this.queue = new ChannelLinkedList<>();
		try {
			ExecutorService threadPool = Executors.newFixedThreadPool(4);
			AsynchronousChannelGroup asyncChannelGroup = AsynchronousChannelGroup.withThreadPool(threadPool);
			socketChannel = AsynchronousSocketChannel.open(asyncChannelGroup);
			socketChannel.connect(new InetSocketAddress(host, this.port)).get();
		} catch (IOException | InterruptedException | ExecutionException e) {
			System.out.println("Error on open socket");
			e.printStackTrace();
			System.exit(1);
		}
	}

	public MessageEvent getEvent() {
		return event;
	}

	public void setEvent(MessageEvent event) {
		this.bm = new AsynBufferedMessage(event);
		this.event = event;
	}
	
	private void doRead() {
		ByteBuffer buffer = ByteBuffer.allocate(size);
		socketChannel.read(buffer, null, new CompletionHandler<Integer, Void>() {

			@Override
			public void completed(Integer arg0, Void arg1) {
				buffer.flip();
				byte[] bytes = new byte[buffer.remaining()];
				buffer.get(bytes);
				String message = new String(bytes);
				bm.append(message);
				buffer.compact();
				queue.write(socketChannel);
				socketChannel.read(buffer, null, this);
			}

			@Override
			public void failed(Throwable arg0, Void arg1) {
				
			}
		});
	}

	public void send(String message) throws IOException, InterruptedException, ExecutionException {
		this.queue.addLast(message);
		this.queue.write(socketChannel);
	}

	public void recv() {
		doRead();
	}
}