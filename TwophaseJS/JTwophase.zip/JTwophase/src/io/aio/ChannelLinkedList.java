package io.aio;

import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.LinkedList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ChannelLinkedList<E> extends LinkedList<E> {
	private static final long serialVersionUID = 1L;
	private String name;
	private ChannelLinkedList<E> me;
	private boolean available;
	
	public ChannelLinkedList() {
		super();
		this.name = "";
		this.available = true;
		me = this;
	}
	
	public void write(AsynchronousSocketChannel channel) {
		if(this.size() == 0) return;
		synchronized(channel) {
			if(this.size() == 0 || !this.available) return;
			this.available = false;
			E msg = this.pollFirst();
			if(msg == null) {
				this.available = true;
				return;
			}
			ByteBuffer writeBuffer =  ByteBuffer.wrap(msg.toString().getBytes());
			channel.write(writeBuffer, null, new CompletionHandler<Integer, Void>() {
				@Override
				public void completed(Integer result, Void attachment) {
					synchronized(channel) {
						me.available = true;
					}
					me.write(channel);
				}
	
				@Override
				public void failed(Throwable exc, Void attachment) {
					me.write(channel);
				}
			});
		}
	}
	
	public synchronized void getLock() {
		while (available == false) {
			try {
				wait();
			} catch (InterruptedException e) {
			}
		}
		available = false;
		notifyAll();
	}

	public synchronized void releaseLock() {
		while (available == true) {
			try {
				wait();
			} catch (InterruptedException e) {
			}
		}
		available = true;
		notifyAll();
	}

}
