package io.aio;

import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.LinkedList;

public class ChannelLinkedList<E> extends LinkedList<E> {
	private static final long serialVersionUID = 1L;
	
	private boolean writing;
	private String name;
	private ChannelLinkedList<E> me;
	
	public ChannelLinkedList() {
		super();
		this.writing = false;
		this.name = "";
		me = this;
	}
	
	public synchronized void write(AsynchronousSocketChannel channel) {
		if(this.size() == 0 || this.writing) return;
		this.setWriting(true);
		String msg = this.pollFirst().toString();
		ByteBuffer writeBuffer =  ByteBuffer.wrap(msg.getBytes());
		System.out.println("Write " + msg);
		channel.write(writeBuffer, null, new CompletionHandler<Integer, Void>() {
			@Override
			public void completed(Integer result, Void attachment) {
				me.setWriting(false);
				if(me.size() != 0) {
					me.write(channel);
				}
			}

			@Override
			public void failed(Throwable exc, Void attachment) {
				
			}
		});
	}
	
//	public void getFirst() {
//		synchronized(this) {
//			this.addLast(e);
//		}
//	}
	
	public void setLast(E e) {
		synchronized(this) {
			this.addLast(e);
		}
	}
	
	public boolean isWriting() {
		return writing;
	}
	public synchronized void setWriting(boolean writing) {
		this.writing = writing;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
