package io.aio;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousChannelGroup;
import java.nio.channels.AsynchronousServerSocketChannel;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import base.MessageEvent;
import base.States;
import io.Message;

public class AIOServer4 {
	private AsynchronousServerSocketChannel serverChannel;
	private MessageEvent event;
	private ArrayList<AsynchronousSocketChannel> channels;
	private AsynBufferedMessage bm;
	private HashMap<AsynchronousSocketChannel, ChannelLinkedList<String>> buffers;
	private boolean isReading;
	private int size;
	private int defaultConnections;
	
	public AIOServer4(int port) {
		try {
			channels = new ArrayList<>();
			buffers = new HashMap<>();
			size = 1024;
//			size = 1024;
			ExecutorService threadPool = Executors.newFixedThreadPool(4);
			AsynchronousChannelGroup asyncChannelGroup = AsynchronousChannelGroup.withThreadPool(threadPool);
			serverChannel = AsynchronousServerSocketChannel.open(asyncChannelGroup);
			serverChannel.bind(new InetSocketAddress(port));
			isReading = false;
			defaultConnections = 3;
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	public MessageEvent getEvent() {
		return event;
	}

	public void setEvent(MessageEvent event) {
		this.bm = new AsynBufferedMessage(event);
		this.event = event;
		this.tryToRead();
	}

	public void acceptChannel() {
		serverChannel.accept(null, new CompletionHandler<AsynchronousSocketChannel,Void>() {

			@Override
			public void completed(AsynchronousSocketChannel result, Void attachment) {
//				System.out.println("Thread " + Thread.currentThread().getName() + " executing callback");
				channels.add(result);
				buffers.put(result, new ChannelLinkedList<String>());
				if(channels.size() < defaultConnections) {
					acceptChannel();
				} else {
					tryToRead();
				}
			}

			@Override
			public void failed(Throwable exc, Void attachment) {
				// TODO Auto-generated method stub
				
			}
		});
	}
	
	public void tryToRead() {
		try {
			if(this.channels.size() == defaultConnections && this.bm != null && !isReading) {
				isReading = true;
				for(AsynchronousSocketChannel c : channels) {
					doRead(c);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void doWrite(AsynchronousSocketChannel channel, String message) throws IOException {
		ByteBuffer writeBuffer = ByteBuffer.wrap(message.getBytes());
		try {
			synchronized(channel) {
				Future f = channel.write(writeBuffer);
				if(!f.isDone()) {
					f.get();
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
	}

	private void doRead(AsynchronousSocketChannel sc) throws IOException {
		ByteBuffer buffer = ByteBuffer.allocate(size);
		sc.read(buffer, null, new CompletionHandler<Integer, Void>() {

			@Override
			public void completed(Integer arg0, Void arg1) {
				buffer.flip();
				byte[] bytes = new byte[buffer.remaining()];
				buffer.get(bytes);
				String message = new String(bytes);
//				System.out.println("Thread " + Thread.currentThread().getName() 
//						+ " executing read for connection " + sc.toString());
				bm.append(message, sc);
				buffer.compact();
				sc.read(buffer, null, this);
			}

			@Override
			public void failed(Throwable arg0, Void arg1) {
				
			}
			
		});
	}
	
	public void send(String message) throws IOException {
		for(AsynchronousSocketChannel c : channels) {
			doWrite(c, message);
		}
	}

	public void run() {
		this.acceptChannel();
	}

	public int getDefaultConnections() {
		return defaultConnections;
	}

	public void setDefaultConnections(int defaultConnections) {
		this.defaultConnections = defaultConnections;
	}

	public void recv() {
		tryToRead();
	}
	
	
}
