package io.aio;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.util.LinkedList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import base.MessageEvent;
import io.Message;

public class AIOClient {
	private String host;
	private int port;
	private AsynchronousSocketChannel socketChannel;
	private MessageEvent event;
	private AsynBufferedMessage bm;
	private boolean reading;

	public AIOClient(String ip, int port) {
		this.host = ip;
		this.port = port;
		this.reading = false;
		try {
			socketChannel = AsynchronousSocketChannel.open();
			socketChannel.connect(new InetSocketAddress(host, this.port)).get();
		} catch (IOException | InterruptedException | ExecutionException e) {
			System.out.println("Error on open socket");
			e.printStackTrace();
			System.exit(1);
		}
	}

	public MessageEvent getEvent() {
		return event;
	}

	public void setEvent(MessageEvent event) {
		this.bm = new AsynBufferedMessage(event);
		this.event = event;
	}
	
	private void doRead() {
		while(true) {
			if(!this.reading) {
				this.reading = true;
				ByteBuffer buffer = ByteBuffer.allocate(1024);
				Future f = socketChannel.read(buffer);
				try {
					f.get();
					buffer.flip();
					byte[] bytes = new byte[buffer.remaining()];
					buffer.get(bytes);
					String message = new String(bytes);
//					System.out.println("Client Recv " + message);
					bm.append(message);
					buffer.compact();
					this.reading = false;
				} catch (InterruptedException | ExecutionException e) {
					System.out.println("Error on read data");
					e.printStackTrace();
				} 
			}
			
		}
	}

	public void send(String msg) throws IOException, InterruptedException, ExecutionException {
//		System.out.println("Client Send:: " + msg);
		try {
			synchronized(socketChannel) {
				ByteBuffer writeBuffer = ByteBuffer.wrap(msg.getBytes());
				Future<Integer> result = socketChannel.write(writeBuffer);
				result.get();
			}
		} catch (InterruptedException | ExecutionException e) {
			System.out.println("Error on write data");
			e.printStackTrace();
		} 
	}

	public void recv() {
		doRead();
	}
}