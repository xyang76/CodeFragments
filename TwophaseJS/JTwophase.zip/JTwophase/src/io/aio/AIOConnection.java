package io.aio;

import java.io.*;
import java.util.concurrent.ExecutionException;

import base.Connection;
import base.MessageEvent;
import io.Message;

public class AIOConnection implements Connection {
	private AIOServer3 server;
	private AIOClient3 client;
	boolean isServer;

	@Override
	public void send(Message m) {
		try {
			if (isServer) {
				server.send(m.toString() + "\n");
			} else {
				client.send(m.toString() + "\n");
			}
		} catch (IOException | InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void bind(MessageEvent event) {
		if (isServer) {
			server.setEvent(event);
		} else {
			client.setEvent(event);
		}

	}

	@Override
	public void init(String ip, int port, int conn) {
		if (ip == null) {
			server = new AIOServer3(port);
			server.setDefaultConnections(conn);
			server.run();
			isServer = true;
		} else {
			client = new AIOClient3(ip, port);
			isServer = false;
		}

	}

	@Override
	public void close() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean connected() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void recv() {
		if (isServer) {
			server.recv();
		} else {
			client.recv();
		}
	}

}
