package io.aio;

import java.util.LinkedList;

public class NamedLinkedList<E> extends LinkedList<E> {
	private static final long serialVersionUID = 1L;
	
	private boolean reading;
	private boolean writing;
	private String name;
	
	public NamedLinkedList() {
		super();
		this.reading = false;
		this.writing = false;
		this.name = "";
	}
	
	public boolean isReading() {
		return reading;
	}
	public void setReading(boolean reading) {
		this.reading = reading;
	}
	public boolean isWriting() {
		return writing;
	}
	public void setWriting(boolean writing) {
		this.writing = writing;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
