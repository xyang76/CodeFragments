package io;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.LinkedList;

import base.Connection;
import base.MessageEvent;
import base.States;

public class TCPConnection implements Connection{
	ArrayList<ServerThread> threads;
	
	public TCPConnection() {
		this.threads = new ArrayList<>();
	}
	
	@Override
	public void send(Message m) {
		m.setTag(true);
		for(ServerThread t : threads) {
			t.addMessage(m);
		}
	}

	@Override
	public void bind(MessageEvent e) {
		for(ServerThread t : threads) {
			Message m = new Message(false);
			t.setEvent(e);
			t.addMessage(m);
		}
	}

	@Override
	public void init(String ip, int port, int conn) {
		try {
			if(ip == null) {
				int counter = 0;
				ServerSocket ss = new ServerSocket(port);
				while(counter < 3) {
					Socket s = ss.accept();
					ServerThread st = new ServerThread(s);	
					st.tool = counter;
					st.isClient = false;
					this.threads.add(st);
					st.start();
					counter++;
				}
				System.out.println("---------------Ready!---------------");
			} else {
				Socket s = new Socket(ip, port);
				ServerThread st = new ServerThread(s);
				st.tool = 888;
				st.isClient = true;
				this.threads.add(st);
			}
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void close() {
		
	}
	
	class ServerThread extends Thread						//Thread to handle client request
	{
		Socket client;
		BufferedReader input;
		PrintWriter output;
		int tool;
		boolean isClient;
		LinkedList<Message> list;
		MessageEvent event;

		public void addMessage(Message msg) {
			this.list.push(msg);
			if(this.isClient) {
				try {
					this.pick();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		public void pick() throws IOException {
			Message m = this.list.poll();
			if(m == null) {
				return;
			}
			if(!this.isClient) {
				System.out.println("Server is send? " + m.isTag() + " " + this.list.size());
			}
			if(m.isTag()) {
				System.out.println("Client?" + this.isClient +  " do Send::" + m.toString());
				this.output.write(m.toString() + "\n");
				this.output.flush();
				if(!this.isClient) {
					System.out.println("Server finish send." + this.list.size());
				}
			} else {
				System.out.println("Client?" + this.isClient + " do Recv::");
				String value = this.input.readLine();
				System.out.println("Do Recv:::" + value);
				Message msg = Message.newInstance(value);
				if(msg.getState() == States.COMMIT || msg.getState() == States.ABORT) {
					System.out.println("111111111111111:::" + value);
				}
				this.event.onReadFinish(msg);
			}
		}

		public ServerThread(Socket c)						//Connect to client socket stream
		{
			this.client = c;
			this.list = new LinkedList<Message>();
			InputStreamReader reader;
			OutputStreamWriter writer;
			try
			{
				reader = new InputStreamReader(client.getInputStream());
				writer = new OutputStreamWriter(client.getOutputStream());
				input = new BufferedReader(reader);
				output = new PrintWriter(writer, true);
			}
			catch (IOException e)
			{
				System.out.println(e.getMessage());
			}
		}
		
		public void run() {
			try {
				while(true) {
					this.pick();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		public MessageEvent getEvent() {
			return event;
		}

		public void setEvent(MessageEvent event) {
			this.event = event;
		}
	}

	@Override
	public boolean connected() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void recv() {
		// TODO Auto-generated method stub
		
	}
}
