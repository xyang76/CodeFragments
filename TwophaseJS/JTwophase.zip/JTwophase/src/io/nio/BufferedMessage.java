package io.nio;

import java.nio.channels.SocketChannel;
import java.util.HashMap;

import base.MessageEvent;
import io.Message;

public class BufferedMessage {
	private StringBuffer buffer;
	private MessageEvent event;
	private HashMap<SocketChannel, StringBuffer> list;
	
	public BufferedMessage(MessageEvent e) {
		this.buffer = new StringBuffer();
		this.list = new HashMap<>();
		this.event = e;
	}
	
	public MessageEvent getEvent() {
		return event;
	}

	public void setEvent(MessageEvent event) {
		this.event = event;
	}

	public void append(String message) {
		int j = 0;
		for(int i = 0; i < message.length(); i++) {
			if(message.charAt(i) == '\n') {
				buffer.append(message.substring(j, i));
				Message m = Message.newInstance(buffer.toString());
				
				
				
				
				buffer = new StringBuffer();
				event.onReadFinish(m);
				j = i + 1;
			}
		}
		buffer.append(message.substring(j));
	}

	public void append(String message, SocketChannel sc) {
		StringBuffer sb = list.get(sc);
		if(sb == null) {
			sb = new StringBuffer();
			list.put(sc, sb);
		}
		
		int j = 0;
		for(int i = 0; i < message.length(); i++) {
			if(message.charAt(i) == '\n') {
				sb.append(message.substring(j, i));
				Message m = Message.newInstance(sb.toString());
				event.onReadFinish(m);
				sb = new StringBuffer();
				list.put(sc, sb);
				j = i + 1;
			}
		}
		sb.append(message.substring(j));
		
	}
}
