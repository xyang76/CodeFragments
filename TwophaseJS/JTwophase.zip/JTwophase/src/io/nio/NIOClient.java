package io.nio;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

import base.MessageEvent;

public class NIOClient extends Thread {
	private String host;
	private int port;
	private Selector selector;
	private SocketChannel socketChannel;
	private volatile boolean started;
	private MessageEvent event;
	private boolean connecting;
	private boolean connected;
	private BufferedMessage bm;

	public NIOClient(String ip, int port) {
		this.host = ip;
		this.port = port;
		this.connecting = false;
		this.connected = false;
		try {
			selector = Selector.open();
			socketChannel = SocketChannel.open();
			socketChannel.configureBlocking(false);
			started = true;
		} catch (IOException e) {
			//open socket error
			System.out.println("Open socket error");
			
			e.printStackTrace();
			System.exit(1);
		}
	}

	public void terminate() {
		started = false;
	}

	@Override
	public void run() {
		try {
			doConnect();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		while (started) {
			try {
				selector.select(1000);
				Set<SelectionKey> keys = selector.selectedKeys();
				Iterator<SelectionKey> it = keys.iterator();
				SelectionKey key = null;
				while (it.hasNext()) {
					key = it.next();
					it.remove();
					try {
						doRead(key);
					} catch (Exception e) {
						e.printStackTrace();
						if (key != null) {
							key.cancel();
							if (key.channel() != null) {
								key.channel().close();
							}
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(1);
			}
		}
	}

	private void doRead(SelectionKey key) throws IOException {
		if (key.isValid()) {
			SocketChannel sc = (SocketChannel) key.channel();
			if (key.isConnectable()) {
				if (sc.finishConnect())
					;
	 			else
					System.exit(1);
			}
			if (key.isReadable()) {
				ByteBuffer buffer = ByteBuffer.allocate(1024);
				int readBytes = sc.read(buffer);
				if (readBytes > 0) {
					buffer.flip();
					byte[] bytes = new byte[buffer.remaining()];
					buffer.get(bytes);
					String result = new String(bytes);
					this.bm.append(result);
					buffer.compact();
				} else if (readBytes < 0) {
					//Read nothing
					System.out.println("Read nothing!");
					key.cancel();
					sc.close();
				}
			}
		}
	}

	public MessageEvent getEvent() {
		return event;
	}

	public void setEvent(MessageEvent event) {
		this.bm = new BufferedMessage(event);
		this.event = event;
	}

	private void doWrite(SocketChannel channel, String message) throws IOException {
//		System.out.println("Client send:: " + message);
		byte[] bytes = message.getBytes();
		ByteBuffer writeBuffer = ByteBuffer.allocate(bytes.length);
		
		writeBuffer.put(bytes);
		writeBuffer.flip();
		try {
			while(!channel.finishConnect());
			channel.write(writeBuffer);
			writeBuffer.compact();
		} catch(Exception e) {
			System.out.println("Write error!");
		}
	}

	private synchronized void doConnect() throws IOException {
		if(!this.connecting && !socketChannel.isConnected() && !socketChannel.isConnectionPending()) {
			this.connecting = true;
			socketChannel.connect(new InetSocketAddress(host, port));
		}
	}

	public void send(String msg) throws IOException {
		doConnect();
		socketChannel.register(selector, SelectionKey.OP_READ);
		doWrite(socketChannel, msg);
	}
	
	public boolean connected() {
		return this.connected;
	}
}