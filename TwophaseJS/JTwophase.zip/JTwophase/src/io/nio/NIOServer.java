package io.nio;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import base.MessageEvent;
import io.Message;

public class NIOServer extends Thread {
	private Selector selector;
	private ServerSocketChannel serverChannel;
	private boolean started;
	private MessageEvent event;
	private ArrayList<SocketChannel> channels;
	private BufferedMessage bm;

	public NIOServer(int port) {
		try {
			channels = new ArrayList<>();
			selector = Selector.open();
			serverChannel = ServerSocketChannel.open();
			serverChannel.configureBlocking(false);
			serverChannel.socket().bind(new InetSocketAddress(port), 1024);
			serverChannel.register(selector, SelectionKey.OP_ACCEPT);
			started = true;
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	public MessageEvent getEvent() {
		return event;
	}

	public void setEvent(MessageEvent event) {
		this.bm = new BufferedMessage(event);
		this.event = event;
	}

	public void terminate() {
		started = false;
	}

	@Override
	public void run() {
		while (started) {
			try {
				selector.select(1000);
				Set<SelectionKey> keys = selector.selectedKeys();
				Iterator<SelectionKey> it = keys.iterator();
				SelectionKey key = null;
				while (it.hasNext()) {
					key = it.next();
					it.remove();
					try {
						doRead(key);
					} catch (Exception e) {
						e.printStackTrace();
						if (key != null) {
							key.cancel();
							if (key.channel() != null) {
								key.channel().close();
							}
						}
					}
				}
			} catch (Throwable t) {
				t.printStackTrace();
			}
		}
		if (selector != null) {
			try {
				selector.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void doRead(SelectionKey key) throws IOException {
		if (key.isValid()) {
			if (key.isAcceptable()) {
				ServerSocketChannel ssc = (ServerSocketChannel) key.channel();
				SocketChannel sc = ssc.accept();
				this.channels.add(sc);
				sc.configureBlocking(false);
				sc.register(selector, SelectionKey.OP_READ);
			}

			if (key.isReadable()) {
				SocketChannel sc = (SocketChannel) key.channel();
				ByteBuffer buffer = ByteBuffer.allocate(1024);
				int readBytes = sc.read(buffer);
				if (readBytes != -1) {
					buffer.flip();
					byte[] bytes = new byte[buffer.remaining()];
					buffer.get(bytes);
					if(bytes.length != 0) {
						String message = new String(bytes);
						this.bm.append(message, sc);
						buffer.compact();
					}
				}
			}
		}
	}

	private void doWrite(SocketChannel channel, String message) throws IOException {
//		System.out.println("Server Send:: " + message);
		byte[] bytes = message.getBytes();
		ByteBuffer writeBuffer = ByteBuffer.allocate(bytes.length);
		writeBuffer.put(bytes);
		writeBuffer.flip();
		channel.write(writeBuffer);
		writeBuffer.compact();;
	}
	
	public void send(String message) throws IOException {
		for(SocketChannel c : channels) {
			doWrite(c, message);
		}
	}
}
