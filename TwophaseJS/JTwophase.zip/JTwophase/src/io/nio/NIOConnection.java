package io.nio;

import java.io.*;

import base.Connection;
import base.MessageEvent;
import io.Message;

public class NIOConnection implements Connection {
	private NIOServer server;
	private NIOClient client;
	boolean isServer;

	@Override
	public void send(Message m) {
		try {
			if (isServer) {
				server.send(m.toString() + "\n");
			} else {
				client.send(m.toString() + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void bind(MessageEvent event) {
		if (isServer) {
			server.setEvent(event);
		} else {
			client.setEvent(event);
		}

	}

	@Override
	public void init(String ip, int port, int conn) {
		if (ip == null) {
			server = new NIOServer(port);
			server.start();
			isServer = true;
		} else {
			client = new NIOClient(ip, port);
			client.start();
			isServer = false;
		}

	}

	@Override
	public void close() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean connected() {
		if(!isServer) {
			return client.connected();
		}
		return false;
	}

	@Override
	public void recv() {
		// TODO Auto-generated method stub
		
	}
}
