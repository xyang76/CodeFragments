package test;

import java.util.concurrent.CountDownLatch;

import base.Cohort;
import base.Connection;
import base.Coordinator;
import io.*;
import io.aio.AIOConnection;
import io.nio.NIOConnection;

public class AIOMain {

	public static void main(String[] args) {
		for(int i = 0; i < 3; i++) {
			new Thread(){
				public void run() {
					Connection c = new AIOConnection();
					c.init("127.0.0.1", 8888, 0);
					new Cohort().run(c);
				}
			}.start();
		}
		
		new Thread(){
			private CountDownLatch serverStatus = new CountDownLatch(1);
			public void run() {
				Connection c = new AIOConnection();
				c.init(null, 8888, 3);
				new Coordinator().run(c);
				try {
					serverStatus.await();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}.start();
		
		
	}

}
