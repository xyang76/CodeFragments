package test;

import java.util.concurrent.CountDownLatch;

import base.Connection;
import base.Coordinator;
import io.aio.AIOConnection;
import io.nio.NIOConnection;

public class TestCoordin {
	private static CountDownLatch serverStatus = new CountDownLatch(1);
	
	public static void main(String[] args) {
		Connection c = new AIOConnection();
		c.init(null, 8888, 3);
		new Coordinator().run(c);
		try {
			serverStatus.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
