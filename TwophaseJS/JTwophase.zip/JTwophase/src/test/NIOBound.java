package test;

import base.Cohort;
import base.Connection;
import base.Coordinator;
import base.MessageEvent;
import io.Message;
import io.aio.AIOConnection;
import io.nio.NIOConnection;

public class NIOBound {

	public static void main(String[] args) {
		for(int i = 0; i < 1000; i++) {
			new Thread(){
				public int index;
				
				public void run() {
					Connection c = new NIOConnection();
					c.init("127.0.0.1", 8888, 0);
					c.send(new Message("Hello world" + index));
				}
				public Thread setIndex(int indx) {
					index = indx;
					return this;
				}
			}.setIndex(i).start();
		}
		
		new Thread(){
			public void run() {
				Connection c = new NIOConnection();
				c.init(null, 8888, 1000);
				c.bind(new MessageEvent() {
					@Override
					public void onReadFinish(Message msg) {
						System.out.println(msg.toString());
					}
					
				});
				
			}
		}.start();

	}

}
