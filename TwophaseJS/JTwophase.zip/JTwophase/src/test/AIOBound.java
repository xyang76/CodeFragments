package test;

import java.util.concurrent.CountDownLatch;

import base.Cohort;
import base.Connection;
import base.Coordinator;
import base.MessageEvent;
import io.Message;
import io.aio.AIOConnection;
import io.nio.NIOConnection;

public class AIOBound {

	public static void main(String[] args) {
		for(int i = 0; i < 2500; i++) {
			new Thread(){
				public int index;
				
				public void run() {
					Connection c = new AIOConnection();
					c.init("127.0.0.1", 8888, 0);
					c.send(new Message("Hello world" + index));
				}
				public Thread setIndex(int indx) {
					index = indx;
					return this;
				}
			}.setIndex(i).start();
		}
		
		new Thread(){
			private CountDownLatch serverStatus = new CountDownLatch(1);
			public void run() {
				Connection c = new AIOConnection();
				c.init(null, 8888, 2500);
				c.bind(new MessageEvent() {
					@Override
					public void onReadFinish(Message msg) {
						System.out.println(msg.toString());
					}
					
				});
				
				try {
					serverStatus.await();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}.start();

	}

}
