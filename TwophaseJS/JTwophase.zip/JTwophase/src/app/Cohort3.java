package app;

import java.util.Scanner;

import base.*;
import io.Message;
import io.aio.AIOConnection;

public class Cohort3 {
	private Connection io;
	private boolean runnable = true;
	
	public static void main(String[] args) {
		Connection c = new AIOConnection();
		c.init("127.0.0.1", 8890, 0);
		System.out.println("Ready");
		new Cohort3().run(c);
		System.out.println("input e to exit!");
		Scanner sc = new Scanner(System.in);
		String line = sc.nextLine();
		if("e".equals(line.toLowerCase())) {
			return;
		}
	}

	public void run(Connection io) {
		this.io = io;
		this.io.bind(new MessageEvent() {
			@Override
			public void onReadFinish(Message m) {
				if(m.getState() == States.REQUEST) {
					vote(m);
				} else if(m.getState() == States.GLOBALABORT) {
					globalAbort(m);
				} else if(m.getState() == States.GLOBALCOMMIT) {
					globalCommit(m);
				} 
			}
		});
		this.io.send(new Message());
		this.io.recv();
	}

	public void vote(Message m) {
//		System.out.println("VOTE" + m.toString());
		m.setState(States.COMMIT);
		this.io.send(m);
	}
	
	public void globalCommit(Message m) {
		System.out.println(m.getId() + " end time:" + System.currentTimeMillis());
	}
	
	public void globalAbort(Message m) {
//		System.out.println("Cohort Rollback " + m.getContent());
//		m.setState(States.DONE);
//		this.io.send(m);
	}

	public Connection getIo() {
		return io;
	}

	public void setIo(Connection io) {
		this.io = io;
	}
	
	public boolean isRunnable() {
		return runnable;
	}

	public void setRunnable(boolean runnable) {
		this.runnable = runnable;
	}
}
