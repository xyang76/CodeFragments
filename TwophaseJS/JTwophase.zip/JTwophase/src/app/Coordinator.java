package app;

import java.util.HashMap;
import java.util.Scanner;

import base.*;
import io.Message;
import io.aio.AIOConnection;

public class Coordinator {
	private Connection io;
	private int cohorts = 3;
	private HashMap<Integer, Message> history;
	private MessageEvent event;
	
	public static void main(String[] args) {
		Connection c = new AIOConnection();
		c.init(null, 8888, 3);
		new Coordinator().run(c);
		System.out.println("input e to exit!");
		Scanner sc = new Scanner(System.in);
		String line = sc.nextLine();
		if("e".equals(line.toLowerCase())) {
			return;
		}
	}

	public void run(Connection io) {
		this.io = io;
		this.history = new HashMap<>();
		this.event = new MessageEvent() {
			@Override
			public void onReadFinish(Message m) {
				if(m.getState() == States.ABORT) {
					abort(m);
				} else if(m.getState() == States.COMMIT) {
					commit(m);
				} else if(m.getState() == States.START) {
					start(m);
				} else if(m.getState() == States.CONNECT) {
					System.out.println(m);
					return;
				}
			}
		};
		this.io.bind(event);
	}
	
	public void start(Message m) {
//		System.out.println("REQUEST" + m.toString());
		m.setState(States.REQUEST);
		this.history.put(m.getId(), m);
		this.io.send(m);
	}
	
	public void commit(Message m) {
//		System.out.println("RECV" + m.toString());
		Message msg = this.history.get(m.getId());
		if(msg == null) {
			return;
		}
		msg.addCounter();
		if(msg.getCounter() == cohorts) {
//			System.out.println("COMMIT" + m.toString());
			msg.setState(States.GLOBALCOMMIT);
			this.io.send(msg);
		}
	}
	
	public void abort(Message m) {
		Message msg = this.history.get(m.getId());
		if(msg == null) {
			return;
		}
		if(msg.getState() != States.GLOBALABORT) {
			msg.setState(States.GLOBALABORT);
			this.io.send(msg);
		}
	}
	
	public Connection getIo() {
		return io;
	}

	public void setIo(Connection io) {
		this.io = io;
	}

	public int getCohorts() {
		return cohorts;
	}

	public void setCohorts(int cohorts) {
		this.cohorts = cohorts;
	}
}
