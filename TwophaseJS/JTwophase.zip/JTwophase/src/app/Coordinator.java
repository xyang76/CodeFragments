package app;

import java.util.HashMap;
import java.util.Scanner;

import base.*;
import io.Message;
import io.aio.AIOConnection;

public class Coordinator {
	private Connection[] io;
	private int cohorts = 3;
	private HashMap<Integer, Message> history;
	private MessageEvent event;
	
	public static void main(String[] args) {
		Connection c1 = new AIOConnection();
		c1.init(null, 8888, 1);
		Connection c2 = new AIOConnection();
		c2.init(null, 8889, 1);
		Connection c3 = new AIOConnection();
		c3.init(null, 8890, 1);
		new Coordinator().run(new Connection[]{c1, c2, c3});
		System.out.println("input e to exit!");
		Scanner sc = new Scanner(System.in);
		String line = sc.nextLine();
		if("e".equals(line.toLowerCase())) {
			return;
		}
	}

	public void run(Connection[] io) {
		this.io = io;
		this.history = new HashMap<>();
		this.event = new MessageEvent() {
			@Override
			public void onReadFinish(Message m) {
				if(m.getState() == States.ABORT) {
					abort(m);
				} else if(m.getState() == States.COMMIT) {
					commit(m);
				} else if(m.getState() == States.START) {
					start(m);
				} else if(m.getState() == States.CONNECT) {
					System.out.println(m);
					return;
				}
			}
		};
		for(int i = 0; i < io.length; i++) {
			this.io[i].bind(event);
		}
	}
	
	public void start(Message m) {
//		System.out.println("REQUEST" + m.toString());
		m.setState(States.REQUEST);
		this.history.put(m.getId(), m);
		doSend(m);
	}
	
	public void commit(Message m) {
//		System.out.println("RECV" + m.toString());
		Message msg = this.history.get(m.getId());
		if(msg == null) {
			return;
		}
		msg.addCounter();
		if(msg.getCounter() == cohorts) {
//			System.out.println("COMMIT" + m.toString());
			msg.setState(States.GLOBALCOMMIT);
			doSend(msg);
		}
	}
	
	public void abort(Message m) {
		Message msg = this.history.get(m.getId());
		if(msg == null) {
			return;
		}
		if(msg.getState() != States.GLOBALABORT) {
			msg.setState(States.GLOBALABORT);
			doSend(msg);
		}
	}
	
	public void doSend(Message msg) {
		for(int i = 0; i < this.io.length; i++) {
			this.io[i].send(msg);
		}
	}
	
	public Connection[] getIo() {
		return io;
	}

	public void setIo(Connection[] io) {
		this.io = io;
	}

	public int getCohorts() {
		return cohorts;
	}

	public void setCohorts(int cohorts) {
		this.cohorts = cohorts;
	}
}
