package app;

import java.util.Scanner;

import base.Connection;
import base.States;
import io.Message;
import io.aio.AIOConnection;

public class App {
	private int proposals = 100000;
	
	public static void main(String[] args) {
		Connection c = new AIOConnection();
		c.init("127.0.0.1", 8887, 0);
		new App().run(c);
	}
	
	public void run(Connection c) {
		c.send(new Message());		//Establish connection
		
		System.out.println("Start time: " + System.currentTimeMillis());
		for(int i = 0; i < proposals; i++) {
			Message m = new Message();
			m.setId(i);
			m.setContent("m");
			m.setState(States.MSG);
			c.send(m);
		}
		System.out.println("input e to exit!");
		Scanner sc = new Scanner(System.in);
		String line = sc.nextLine();
		if("e".equals(line.toLowerCase())) {
			return;
		}
	}

}
