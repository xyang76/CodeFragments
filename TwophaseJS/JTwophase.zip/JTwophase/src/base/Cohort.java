package base;

import io.Message;

public class Cohort {
	private Connection io;
	private boolean runnable = true;
	private MessageEvent event;

	public void run(Connection io) {
		this.io = io;
		this.event = new MessageEvent() {
			@Override
			public void onReadFinish(Message m) {
				if(m.getState() == States.REQUEST) {
					vote(m);
				} else if(m.getState() == States.GLOBALABORT) {
					globalAbort(m);
				} else if(m.getState() == States.GLOBALCOMMIT) {
					globalCommit(m);
				} 
			}
		};
		this.io.bind(event);
		Message m = new Message();
		m.setState(States.CONNECT);
		this.io.send(m);
	}
	
	public void vote(Message m) {
		double v  = Math.random();
		if(v < 0.2) {
			m.setState(States.ABORT);
		} else {
			m.setState(States.COMMIT);
		}
		this.io.send(m);
	}
	
	public void globalCommit(Message m) {
//		System.out.println("Cohort Commit " + m.getContent());
		m.setState(States.DONE);
		this.io.send(m);
	}
	
	public void globalAbort(Message m) {
//		System.out.println("Cohort Rollback " + m.getContent());
		m.setState(States.DONE);
		this.io.send(m);
	}

	public Connection getIo() {
		return io;
	}

	public void setIo(Connection io) {
		this.io = io;
	}
	
	public boolean isRunnable() {
		return runnable;
	}

	public void setRunnable(boolean runnable) {
		this.runnable = runnable;
	}
}
