package base;

import io.Message;

public interface MessageEvent {
	public void onReadFinish(Message msg);
}
