package base;

import java.util.HashMap;

import io.Message;

public class Coordinator {
	private Connection io;
	private int cohorts = 3;
	private int connected = 0;
	private boolean runnable;
	private HashMap<Integer, Message> history;
	private int mid;
	private MessageEvent event;
	
	private long start;
	private long end;
	private int proposals = 1000;
	private int finished = 0;

	public void run(Connection io) {
		this.io = io;
		this.mid = 0;
		this.history = new HashMap<>();
		this.event = new MessageEvent() {
			@Override
			public void onReadFinish(Message m) {
				if(m.getState() == States.ABORT) {
					abort(m);
				} else if(m.getState() == States.COMMIT) {
					commit(m);
				} else if(m.getState() == States.CONNECT) {
					init();
				} else if(m.getState() == States.DONE) {
					
				}
			}
		};
		this.io.bind(event);
	}
	
	public void init() {
		connected++;
		if(connected == cohorts) {
			start = System.currentTimeMillis();
			for(int i = 0; i < proposals; i++) {
				this.request("Hello world" + i);
			}
		}
	}
	
	public void request(String content) {
		Message m = new Message();
		m.setId(mid++);
		m.setContent(content);
		m.setState(States.REQUEST);
		this.history.put(m.getId(), m);
		this.io.send(m);
	}
	
	public void commit(Message m) {
		Message msg = this.history.get(m.getId());
		if(msg == null) {
			return;
		}
		msg.addCounter();
		if(msg.getCounter() == cohorts) {
			msg.setState(States.GLOBALCOMMIT);
			this.io.send(msg);
			
			finished++;
			if(finished > proposals - 10) {
				end =  System.currentTimeMillis();
				System.out.println("Time elapse:" + (end - start));
			}
		}
	}
	
	public void abort(Message m) {
		Message msg = this.history.get(m.getId());
		if(msg == null) {
			return;
		}
		if(msg.getState() != States.GLOBALABORT) {
			msg.setState(States.GLOBALABORT);
			this.io.send(msg);
			
			finished++;
			if(finished > proposals - 10) {
				end =  System.currentTimeMillis();
				System.out.println("Time elapse:" + (end - start));
			}
		}
	}
	
	public Connection getIo() {
		return io;
	}

	public void setIo(Connection io) {
		this.io = io;
	}

	public int getCohorts() {
		return cohorts;
	}

	public void setCohorts(int cohorts) {
		this.cohorts = cohorts;
	}

	public boolean isRunnable() {
		return runnable;
	}
}
