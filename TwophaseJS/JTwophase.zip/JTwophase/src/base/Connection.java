package base;

import io.Message;

public interface Connection {
	public void send(Message m);
	public void bind(MessageEvent e);
	public void recv();
	public void init(String ip, int port, int conn);
	public void close();
	public boolean connected();
}
