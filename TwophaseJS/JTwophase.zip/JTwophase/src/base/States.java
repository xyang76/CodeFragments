package base;

public enum States {
	CONNECT,
	REQUEST,
	ABORT,
	COMMIT,
	GLOBALABORT,
	GLOBALCOMMIT,
	MSG,
	START,
	DONE
}