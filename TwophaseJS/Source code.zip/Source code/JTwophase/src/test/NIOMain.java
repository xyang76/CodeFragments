package test;

import base.Cohort;
import base.Connection;
import base.Coordinator;
import io.*;
import io.aio.AIOConnection;
import io.nio.NIOConnection;

public class NIOMain {

	public static void main(String[] args) {
		for(int i = 0; i < 3; i++) {
			new Thread(){
				public void run() {
					Connection c = new NIOConnection();
					c.init("127.0.0.1", 8888);
					new Cohort().run(c);
				}
			}.start();
		}
		
		new Thread(){
			public void run() {
				Connection c = new NIOConnection();
				c.init(null, 8888);
				new Coordinator().run(c);
			}
		}.start();
		
		
	}

}
