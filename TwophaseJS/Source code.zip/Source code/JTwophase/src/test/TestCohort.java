package test;

import base.Cohort;
import base.Connection;
import io.aio.AIOConnection;
import io.nio.NIOConnection;

public class TestCohort {
	public static void main(String[] args) {
		Connection c = new AIOConnection();
		c.init("127.0.0.1", 8888);
		new Cohort().run(c);
	}
}
