package base;

public enum States {
	CONNECT,
	VOTEREQUEST,
	VOTEABORT,
	VOTECOMMIT,
	GLOBALABORT,
	GLOBALCOMMIT,
	DONE
}