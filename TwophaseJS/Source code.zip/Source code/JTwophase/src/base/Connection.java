package base;

import io.Message;

public interface Connection {
	public void send(Message m);
	public void recv(MessageEvent e);
	public void init(String ip, int port);
	public void close();
	public boolean connected();
}
