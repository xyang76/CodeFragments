package io.aio;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousServerSocketChannel;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import base.MessageEvent;

public class AIOServer1{
	private AsynchronousServerSocketChannel serverChannel;
	private MessageEvent event;
	private ArrayList<AsynchronousSocketChannel> channels;
	private AsynBufferedMessage bm;
	private HashMap<AsynchronousSocketChannel, ByteBuffer> buffers;
	private boolean isReading;
	
	public AIOServer1(int port) {
		try {
			channels = new ArrayList<>();
			buffers = new HashMap<>();
			serverChannel = AsynchronousServerSocketChannel.open();
			serverChannel.bind(new InetSocketAddress(port), 1024);
			isReading = false;
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	public MessageEvent getEvent() {
		return event;
	}

	public void setEvent(MessageEvent event) {
		this.bm = new AsynBufferedMessage(event);
		this.event = event;
		this.tryToRead();
	}

	public void acceptChannel() {
		serverChannel.accept(null, new CompletionHandler<AsynchronousSocketChannel,Void>() {

			@Override
			public void completed(AsynchronousSocketChannel result, Void attachment) {
				channels.add(result);
				buffers.put(result, ByteBuffer.allocate(1024));
				if(channels.size() < 3) {
					acceptChannel();
				} else {
					tryToRead();
				}
			}

			@Override
			public void failed(Throwable exc, Void attachment) {
				// TODO Auto-generated method stub
				
			}
		});
	}
	
	public void tryToRead() {
		try {
			if(this.channels.size() == 3 && this.bm != null && !isReading) {
				isReading = true;
				for(AsynchronousSocketChannel c : channels) {
					doRead(c);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void doWrite(AsynchronousSocketChannel channel, String message) throws IOException {
		ByteBuffer writeBuffer = ByteBuffer.wrap(message.getBytes());
		try {
			channel.write(writeBuffer).get();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
	}

	private void doRead(AsynchronousSocketChannel sc) throws IOException {
		
		ByteBuffer buffer = ByteBuffer.allocate(1024);
		sc.read(buffer, null, new CompletionHandler<Integer, Void>() {

			@Override
			public void completed(Integer arg0, Void arg1) {
				buffer.flip();
				byte[] bytes = new byte[buffer.remaining()];
				buffer.get(bytes);
				String message = new String(bytes);
				System.out.println("Recv " + message);
				bm.append(message, sc);
				buffer.clear();
				sc.read(buffer, null, this);
			}

			@Override
			public void failed(Throwable arg0, Void arg1) {
				sc.read(buffer, null, this);
			}
			
		});
		
		
//		new Thread() {
//			int index;
//			
//			public Thread setIndex(int indx) {
//				this.index = indx;
//				return this;
//			}
//			
//			@Override
//			public void run() {
//				AsynchronousSocketChannel sc = channels.get(this.index);
//				ByteBuffer buffer = ByteBuffer.allocate(1024);
//				sc.read(buffer, null, new CompletionHandler<Integer, Void>() {
//
//					@Override
//					public void completed(Integer arg0, Void arg1) {
//						buffer.flip();
//						byte[] bytes = new byte[buffer.remaining()];
//						buffer.get(bytes);
//						String message = new String(bytes);
//						System.out.println("Recv" + message);
//						bm.append(message, sc);
//						buffer.clear();
//					}
//
//					@Override
//					public void failed(Throwable arg0, Void arg1) {
//						
//					}
//					
//				});
//					
//			}
//		}.setIndex(i).start();
	}
	
	public void send(String message) throws IOException {
		for(AsynchronousSocketChannel c : channels) {
			doWrite(c, message);
		}
	}

	public void run() {
		this.acceptChannel();
		
		
	}
}
