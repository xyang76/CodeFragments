package io;

import base.States;

public class Message {
	private String content;
	private States state;
	private int id;
	private int counter;
	private boolean tag;

	public Message() {
		this.id = 0;
		this.counter = 0;
		this.state = States.CONNECT;
	}
	
	public Message(boolean tag) {
		this();
		this.tag = tag;
	}
	
	public Message(String content) {
		this();
		this.content = content;
	}
	
	public static Message newInstance(String data) {
		String[] str = data.split("\\|");
		Message m = new Message();
		m.setId(Integer.parseInt(str[0]));
		m.setContent(str[1]);
		m.setState(States.valueOf(str[2]));
		return m;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public States getState() {
		return state;
	}

	public void setState(States state) {
		this.state = state;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public int getCounter() {
		return counter;
	}

	public void addCounter() {
		this.counter++;
	}
	
	public boolean isTag() {
		return tag;
	}

	public void setTag(boolean tag) {
		this.tag = tag;
	}
	
	@Override
	public String toString() {
		return this.id + "|" + this.content + "|" + this.state.toString();
	}
}
