/**
 * 
 */
var Cohort = function() {
	var ProcMessage = require('./ProcMessage');
	var me = this;
	this.history = new Map();
	
	this.callbackFunction = function(proposal) {
		switch(proposal.state) {
			case 'VOTEREQUEST': 
				me.request(proposal);
				break;
			case 'GLOBALABORT':
				me.globalAbort(proposal);
				break;
			case 'GLOBALCOMMIT':
				me.globalCommit(proposal);
				break;
			case 'CLOSE':
				me.tms.close();
				break;
		}
	}
	
	this.run = function(target) {
		var tms = new ProcMessage(target, false);  // Proc version JMS
		tms.subscribe(me.callbackFunction);
		tms.publish({state : 'CONNECT'});
		me.tms = tms;
	}
	
	this.request = function(prop) {
		var v = Math.random();
		me.history.set(prop.id, prop);
		
		if(v < 0.2) {
			this.voteNo(prop);
		} else {
			this.voteYes(prop);
		}
	}
	
	this.voteNo = function(prop) {
		prop.state = 'VOTEABORT';
		me.tms.publish(prop);
	}
	
	this.voteYes = function(prop) {
		prop.state = 'VOTECOMMIT';
		me.tms.publish(prop);
		
		setTimeout(function () {
			// Still haven't change state
			if(prop.state == 'VOTECOMMIT') {
				me.requestOthers(prop);
			}
		}, 100);
	}
	
	this.globalCommit = function(prop) {
//		console.log("Cohort commit");
		me.history.get(prop.id).state = 'DONE';
		me.tms.publish('DONE');
	}
	
	this.globalAbort = function(prop) {
//		console.log("Cohort abort");
		me.history.get(prop.id).state = 'DONE';
		me.tms.publish('DONE');
	}
	
	this.requestOthers = function(prop) {
		
	}
}

module.exports = function(){
	return new Cohort();
}