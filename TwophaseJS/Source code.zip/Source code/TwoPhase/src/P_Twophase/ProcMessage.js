/**
 * ProcMessage
 */
var procServer = function(clients) {
	this.clients = clients;
	this.publish = function(message) {
		for (const id in clients) {
//			console.log('[Send message]:' + JSON.stringify(message)); 
			clients[id].send({type : 'msg', content: message});
		}
	}
	this.subscribe = function(callback) {
		this.subcb = callback;
	}
	this.invoke = function(msg) {
		if(this.subcb) {
//			console.log('[Recv message]:' + JSON.stringify(msg.content)); 
			this.subcb(msg.content);
		}
	}
}
	
var procClient = function(server) {
	this.server = server;
	this.publish = function(message) {
		server.send({type : 'msg', content: message});
	}
	this.subscribe = function(callback) {
		this.subcb = callback;
	}
	this.invoke = function(msg) {
		if(this.subcb) {
			this.subcb(msg.content);
		}
	}
}

module.exports = function(target, isServer){
	if(isServer) {
		return new procServer(target);
	} else {
		return new procClient(target);
	}
}