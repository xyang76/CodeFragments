const cluster = require('cluster');
const PCoordinator = require('./PCoordinator.js');
const PCohort = require('./PCohort.js');

if (cluster.isMaster) {
	for(i = 0; i < 3; i++) {
		cluster.fork();
	}
	var coordin = new PCoordinator(3);
	coordin.run(cluster.workers);
	process.on('message', function(msg){
		coordin.tms.invoke(msg);
	});
} else {
	var cohort = new PCohort();
	cohort.run(process);
	process.on('message', function(msg){
		cohort.tms.invoke(msg);
	});
}