/**
 * 
 */
var Coordinator = function(cohorts) {
	var ProcMessage = require('./ProcMessage');
	var me = this;
	this.proposals = [];
	this.propId = 0;
	this.counter = 0;
	this.cohorts = cohorts;
	
	this.callbackFunction = function(proposal) {
		switch(proposal.state) {
			case 'CONNECT':
				break;
			case 'VOTEABORT': 
				me.abort(proposal);
				break;
			case 'VOTECOMMIT':
				me.commit(proposal);
				break;
			case 'DONE':
				break;
		}
	}
	
	this.run = function(items) {
		// A callback only if all cohorts are ready
		var tms = new ProcMessage(items, true); // TCP version JMS
		me.tms = tms;
		tms.subscribe(me.callbackFunction);
//		tms.event.newclient = function(){
//			if(tms.sockets.length == me.cohorts) {
//				console.log("Coord ready!");
//				me.start = new Date();
//				
//			}
//		}
		
		me.start = new Date();
		for(var i = 0; i < 5; i++) {
			me.request("Hello world" + i, me.callbackFunction);
		}
		
	}
	
	this.request = function(msg, callbackFunction) {
		var Proposal = function(msg){
			return {	
				message : msg,
				state : 'VOTEREQUEST',
				counter : 0,
				id : me.proposals.length
			}
		}
		var prop = new Proposal(msg);
		this.proposals.push(prop);
		this.tms.publish(prop);
		
		setTimeout(function () {
			if(prop.counter < cohorts) {
			   me.abort(prop);
			}
		}, 100);
	}
	
	this.abort = function(prop) {
		var fp = this.proposals[prop.id];
		fp.state = 'GLOBALABORT';
		me.sendMessage(fp);
	}
	
	this.commit = function(prop) {
		var fp = this.proposals[prop.id];
		fp.counter++;
		if(fp.counter == me.cohorts) {
			fp.state = 'GLOBALCOMMIT';
			me.sendMessage(fp);
		}
	}
	
	this.sendMessage = function(prop) {
		this.tms.publish(prop);
		me.counter++;
		
		if(me.counter > 490) {
			me.end = new Date();
			var diff = me.end - me.start;
			console.log('[TIME ELAPSE(ms)----------------------------]' + diff);
		}
	}
}

module.exports = function(cohorts){
	return new Coordinator(cohorts);
}