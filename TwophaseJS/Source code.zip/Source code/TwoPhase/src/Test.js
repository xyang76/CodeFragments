/**
 * 
 */
var c1 = function() {
	this.test1 = function() {
		console.log("C1 test1 " + this.value);
	}
	this.test2 = function() {
		console.log("C1 test2 " + this.value);
	}
	this.value = 100;
}

var c2 = function() {
	var me = this;
	me.test1 = function() {
		console.log("C2 test1 " + me.value);
	} 
	me.value = 200;
	return me;
}

c2.prototype = new c1();
var c3 = new c2();
c3.test1();
c3.test2();


