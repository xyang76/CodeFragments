/**
 * 
 */
var cp = require('child_process');

const coordinator = cp.fork('./Coordinator3.js');
const cohort1 = cp.fork('./Cohort3.js');
const cohort2 = cp.fork('./Cohort3.js');
const cohort3 = cp.fork('./Cohort3.js');

coordinator.send({type : 'init3', cohorts: 3});
cohort1.send('init3');
cohort2.send('init3');
cohort3.send('init3');


