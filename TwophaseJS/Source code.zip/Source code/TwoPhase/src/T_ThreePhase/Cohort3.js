/**
 * 
 */
var Cohort = require('./Cohort');

var Cohort3 = function() {
	var me = new Cohort();
	var timeout = 100;
	
	me.callbackFunction = function(proposal) {
		switch(proposal.state) {
			case 'VOTEREQUEST': 
				me.request(proposal);
				break;
			case 'PRECOMMIT':
				me.precommit(proposal);
				break;
			case 'GLOBALABORT':
				me.globalAbort(proposal);
				break;
			case 'GLOBALCOMMIT':
				me.globalCommit(proposal);
				break;
			case 'CLOSE':
				me.tms.close();
				break;
		}
	}
	
	me.precommit = function(prop) {
		var msg = me.history.get(prop.id);
		msg.state = 'ACK';
		me.tms.publish(msg);
		
		setTimeout(function () {
			if(msg.state == 'ACK') {
				me.requestOthers(msg);
			}
		}, timeout);
	}
	
	return me;
}

Cohort3.prototype = new Cohort();

//console.log('[Cohort pid] ' + process.pid);
process.on('message', function(msg){
	if(msg == 'init3') {
//		console.log('[Init] cohort init.');
		new Cohort3().run();
	}
});