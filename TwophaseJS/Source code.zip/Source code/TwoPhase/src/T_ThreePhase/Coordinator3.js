/**
 * 
 */
var Coordinator = require('./Coordinator');

var Coordinator3 = function(cohorts) {	
	var me = new Coordinator(cohorts);
	var timeout = 100;
	
	me.callbackFunction = function(proposal) {
		switch(proposal.state) {
			case 'CONNECT':
				break;
			case 'ACK':
				me.commit(proposal);
				break;
			case 'VOTEABORT': 
				me.abort(proposal);
				break;
			case 'VOTECOMMIT':
				me.precommit(proposal);
				break;
			case 'DONE':
				break;
		}
	}
	
	me.precommit = function(prop) {
		var fp = me.proposals[prop.id];
		fp.counter++;
		if(fp.counter == me.cohorts) {
			fp.state = 'PRECOMMIT';
			fp.counter = 0;		//Reset counter for globalCommit
			me.tms.publish(fp);
			
			setTimeout(function () {
				// DO NOTHING VS GLOBAL COMMIT
				if(fp.counter < cohorts) {
					fp.state = 'GLOBALCOMMIT';
					me.sendMessage(fp);
				}
			}, timeout);
		}
	}
	return me;
}

console.log('[Coordinator pid] ' + process.pid);
process.on('message', function(msg){
	if(msg.type == 'init3') {
		console.log('[Init] Coordinator init.');
		Coordinator3.prototype = new Coordinator(msg.cohorts);
		new Coordinator3(msg.cohorts).run();
	}
});