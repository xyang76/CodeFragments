/**
 * 
 */
var App = function(index) {
	var TCPMessage = require('./TCPMessage');
	var cms = new TCPMessage('127.0.0.1', 8887, false);  // TCP version JMS
	cms.name = 'App';
	var me = this;
	this.index = index;
	this.props = 10;
	
	this.run = function() {
		cms.publish({code : 'CONNECT'});
		console.log("Start time is " + new Date().getTime());
		for(var i = 0; i < this.props; i++) {
			var num = i + this.index * this.props;
			cms.publish({code : 'MSG', msg : "Hello world", id : num});
		}
	}
}

//console.log('[Cohort pid] ' + process.pid);
process.on('message', function(msg){
	if(msg.type == 'init') {
		console.log("Init with procId: " + process.pid);
		new App(msg.index).run();
	}
});

process.on('uncaughtException', function(err) {
    console.log(err);
}); 

//module.exports = function(msg){
//	return new App(msg.index).run();
//}


//new App().run();