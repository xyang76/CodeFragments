
/**
 * TCPMessage
 * 
 * Messages are split with '\n'
 * 
 */
var net = require('net');

var splitter = '\n';
var BufferedMessage = function(){
	var msg = '';
	this.append = function(data, callback) {
		var j = 0;
		var value = data.toString();
		for(i = 0; i < value.length; i++) {
			if(value.charAt(i) == splitter) {
				var tmp = value.substring(j, i);
				msg = msg.concat(tmp);
//				console.log(" receive: " + msg);
				callback(JSON.parse(msg));
				msg = '';
				j = i + 1;
			}
		}
		msg = msg.concat(value.substring(j));
	}
}

var TCPServer = function(host, port) {
	var me = this;
	this.name = 'unknown';
	this.host = host;
	this.port = port;
	this.sockets = [];
	// For server part, publish is broadcast
	this.publish = function(message) {
		var str = JSON.stringify(message) + splitter;
		this.sockets.forEach(function(socket){
			socket.write(str);
		})
	}
	// Subscribe is a callback
	this.subscribe = function(callback) {
		this.subcb = callback;
	}
	this.event = {
		"newclient" : function(me){}	
	}
	this.server = net.createServer();
	this.server.on("connection", function(sock) {
		me.sockets.push(sock);
		var buffer = new BufferedMessage();
		sock.on("data", function(data) {
			buffer.append(data, me.subcb);
		});
		sock.on("close", function(){   
            var index = me.sockets.indexOf(sock);  
            me.sockets.splice(index, 1);  
        });  
		
		me.event.newclient(me);
	});
	this.server.on("error", function(error) {
		console.log(me.name + " error:" + JSON.stringify(error));
	});
	this.server.listen(port, host);
	this.close = function(){
		this.server.destory();
	}
}

var TCPClient = function(host, port) {
	var me = this;
	this.name = 'unknown';
	var buffer = new BufferedMessage();
	this.pending = [];
	this.host = host;
	this.port = port;
	this.client = new net.Socket();
	this.client.setTimeout(800000, function(){
	  console.log('Socket timed out');
	});
	this.isConnected = false;
	this.isConnecting = false;
	
	// For client part, publish is send to Server
	this.publish = function(msg) {
		if(!this.isConnecting) {
			this.pending.push(msg);
//			console.log("[Client connecting]: " + JSON.stringify(msg));
			this.isConnecting = true;
			this.connect();
		} else if(!this.isConnected) {
//			console.log("[Client pending]: " + JSON.stringify(msg));
			this.pending.push(msg);
		} else {
			this.write(msg);
		}
	}
	// Subscribe is also a callback
	this.subscribe = function(callback) {
		this.subcb = callback;
	}
	this.close = function() {
		this.client.end();
	}
	this.write = function(msg) {
		this.client.write(JSON.stringify(msg) + splitter);
//		console.log(me.name + " publish: " + JSON.stringify(msg));
	}
	this.connect = function() {
		this.client.connect(this.port, this.host, function(){
			me.isConnected = true;
			console.log("Connect success");
			for(var i = 0; i < me.pending.length; i++) {
				me.write(me.pending[i]);
			}
			me.pending = [];
		});
		this.client.on("data", function(data) {
			buffer.append(data, me.subcb);
		});

		this.client.on("error", function(error) {
			if(error.syscall == "connect") {
				me.client = new net.Socket();
				console.log(me.name + " error:" + JSON.stringify(error));
				me.connect();
			}
		});
	}
}

module.exports = function(host, port, isServer){
	if(isServer) {
		return new TCPServer(host, port);
	} else {
		return new TCPClient(host, port);
	}
}