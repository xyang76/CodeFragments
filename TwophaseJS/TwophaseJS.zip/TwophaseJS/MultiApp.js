var cp = require('child_process');

for(var i = 0; i < 1000; i++) {
	var app = cp.fork('./App.js');
	app.send({type: 'init', index: i});
}