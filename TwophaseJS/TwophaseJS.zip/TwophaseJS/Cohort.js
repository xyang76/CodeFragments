/**
 * 
 */
var Cohort = function() {
	var TCPMessage = require('./TCPMessage');
	var tms = new TCPMessage('127.0.0.1', 8888, false);  // TCP version JMS
	tms.name = 'Cohort';
	var me = this;
	var requests = 1000;
	
	this.counter = 0;
	
	var callbackFunction = function(proposal) {
		switch(proposal.state) {
			case 'REQUEST': 
				me.request(proposal);
				break;
			case 'DECISIONABORT':
				me.decisionAbort(proposal);
				break;
			case 'DECISIONCOMMIT':
				me.decisionCommit(proposal);
				break;
			case 'CLOSE':
				tms.close();
				break;
		}
	}
	
	this.run = function() {
		tms.subscribe(callbackFunction);
		tms.publish({state : 'CONNECT'});
	}
	
	this.request = function(prop) {
		var v = Math.random();
//		if(v < 0.2) {
//			this.voteNo(prop);
//		} else {
			this.voteYes(prop);
//		}
	}
	
	this.voteNo = function(prop) {
		prop.state = 'ABORT';
		tms.publish(prop);
	}
	
	this.voteYes = function(prop) {
		prop.state = 'COMMIT';
		tms.publish(prop);
	}
	
	this.decisionCommit = function(prop) {
//		console.log("Cohort commit");
		me.counter++;
//		if(me.counter == requests) {
			console.log(me.counter + " End time is " + new Date().getTime());
//		}
	}
	
	this.decisionAbort = function(prop) {
//		console.log("Cohort abort");
		me.counter++;
	}
}

//console.log('[Cohort pid] ' + process.pid);
process.on('message', function(msg){
	if(msg == 'init') {
//		console.log('[Init] cohort init.');
		new Cohort().run();
	}
});

process.on('uncaughtException', function(err) {
    console.log(err);
}); 

new Cohort().run();